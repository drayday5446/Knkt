// Service Worker for KNKT
const CACHE_NAME = 'knkt-v1';

self.addEventListener('install', event => {
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('fetch', event => {
  // Let network requests pass through, fallback gracefully if offline
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
