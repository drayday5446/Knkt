# KNKT — Pure OLED Messenger

KNKT is a modern, privacy-first messaging application engineered for true `#000000` OLED displays with dynamic chat grid organization, gesture navigation, and verifiable end-to-end cryptographic packet verification.

---

## ⚡ Core Features

### 1. Pure OLED Display Optimization
- True `#000000` pitch-black canvas with zero backlight gray bleeding.
- Cyberpunk & terminal styling touches (`>_ KNKT` header, monospace command prompt with blinking `█` CMD block cursor).
- Low-power, high-contrast typography and subtle micro-dot read status indicators (Sending, Sent, Delivered, and dual glowing cyan micro-dots for Read).

### 2. Multi-Protocol Engine (SMS, MMS, RCS)
- **SMS**: Carrier Cellular text protocol (slate gray, 160 char limit).
- **MMS**: Multimedia messaging (sky blue, 1000 char limit, photo/audio support).
- **RCS**: Rich Communication Services with Signal Double-Ratchet E2EE (neon cyan, 8000 char limit).
- Instant protocol and E2EE toggle right from the in-thread toolbar bubble.

### 3. Dynamic 1–4 Pinned Chat Grid
- **1 Pinned**: Full-width Banner card with 62px avatar and expanded preview.
- **2 Pinned**: Side-by-side equal column cards.
- **3 Pinned**: Top row of 2 side-by-side cards + full card below.
- **4 Pinned**: 2×2 grid (two rows of 2 cards each).
- Ergonomically placed for easy thumb reach on tall 20:9 screens.

### 4. Interactive Bottom Dock
- Floating condensed circular bubble icon at bottom center.
- Expands to reveal:
  - **New Message / Group Chat** top action button.
  - **Tab Switcher**: Threads (Direct 1-on-1), Groups (3+ members), Media Hub, and Settings.
  - **Live Search Bar**: Search messages, participants, or phone numbers in real time.

### 5. In-Thread Sliding Media Window & Gesture Navigation
- Drag left on conversation cards to peek or slide into active chats.
- In any active chat, drag left or tap the film icon to slide in the dedicated In-Thread Media Window (filtering Photos, Voice Memos, Locations, Documents).
- Configurable right-swipe actions (Mark Read/Unread, Archive Thread, Move to Trash, or Toggle Pin).

### 6. Customizable Message Bubble Theming
- Customize bubble shapes per chat: **Rounded Squircle**, **Sharp Rectangular**, **Smooth Pill**, or **Message Tail**.
- Neon and dark color palette swatches with automatic contrast text luminance calculation.
- **Per-participant styling in Group Chats**: assign unique bubble colors and shapes to individual members!

### 7. End-to-End Cryptographic Security Vault
- **AES-256-GCM** authenticated cipher packets with 128-bit MAC tags and IV inspection.
- **Safety Numbers Verification**: procedural QR matrix and 4-group 5-digit verification codes.
- **Security Vault**: Device Master Identity Key, Curve25519/Ed25519 handshake, active Double-Ratchet sessions, and master keypair rotation.

---

## 🛠 Tech Stack
- **Framework**: React 19 + TypeScript
- **Styling**: Tailwind CSS v4 + Pure OLED Black design system
- **Icons**: Lucide React
- **Haptics & Audio**: Web Audio API synthesized tactile clicks + Vibration API
- **State & Storage**: Persistent reactive storage with seeded demo data matching the Samsung One UI specification
