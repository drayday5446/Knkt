import React, { useState } from 'react';
import { useMessaging } from '../context/MessagingContext';
import {
  Image,
  Mic,
  MapPin,
  FileText,
  ArrowRight,
  Film,
  Lock,
  Play,
} from 'lucide-react';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { MessageEntity } from '../types';
import { HapticHelper } from '../utils/haptics';

interface MediaBrowserScreenProps {
  onShowInChat: (conversationId: number) => void;
}

type MediaFilter = 'ALL' | 'PHOTOS' | 'AUDIO' | 'LOCATIONS' | 'DOCUMENTS';

export const MediaBrowserScreen: React.FC<MediaBrowserScreenProps> = ({
  onShowInChat,
}) => {
  const { messages } = useMessaging();
  const [selectedFilter, setSelectedFilter] = useState<MediaFilter>('ALL');
  const [inspectingMedia, setInspectingMedia] = useState<MessageEntity | null>(null);

  const allMedia = messages.filter(m => !!m.attachmentType);

  const filteredMedia = allMedia.filter(m => {
    switch (selectedFilter) {
      case 'ALL':
        return true;
      case 'PHOTOS':
        return m.attachmentType === 'IMAGE';
      case 'AUDIO':
        return m.attachmentType === 'AUDIO';
      case 'LOCATIONS':
        return m.attachmentType === 'LOCATION';
      case 'DOCUMENTS':
        return m.attachmentType === 'FILE' || m.attachmentType === 'CONTACT';
    }
  });

  const filters: { id: MediaFilter; label: string }[] = [
    { id: 'ALL', label: 'All' },
    { id: 'PHOTOS', label: 'Photos' },
    { id: 'AUDIO', label: 'Voice' },
    { id: 'LOCATIONS', label: 'Locations' },
    { id: 'DOCUMENTS', label: 'Docs' },
  ];

  const formatTimestamp = (ts: number): string => {
    return new Date(ts).toLocaleString([], {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col pb-32">
      {/* Top Header */}
      <div className="w-full pt-4 pb-2 px-4 border-b border-[#141418] bg-black/90 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <KnktCmdChatIcon size={22} glow={true} accentColor="#06B6D4" />
          <span className="font-mono text-base font-extrabold tracking-wider text-white">
            KNKT
          </span>
          <span className="text-[10px] font-mono text-[#06B6D4] font-semibold bg-[#06B6D4]/15 px-1.5 py-0.5 rounded ml-1">
            media
          </span>
        </div>
        <span className="text-xs font-mono text-[#06B6D4]">
          {filteredMedia.length} items
        </span>
      </div>

      {/* Filter Pills */}
      <div className="flex items-center gap-2 px-4 py-2.5 overflow-x-auto no-scrollbar border-b border-[#141418]/60">
        {filters.map(filter => {
          const isSelected = selectedFilter === filter.id;
          return (
            <button
              key={filter.id}
              data-testid={`filter_${filter.id.toLowerCase()}`}
              onClick={() => {
                setSelectedFilter(filter.id);
                HapticHelper.reactionClick();
              }}
              className={`px-3 py-1 rounded-xl text-xs font-mono font-medium transition-all shrink-0 border ${
                isSelected
                  ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4] font-bold'
                  : 'bg-[#0A0A0C] border-[#222226] text-[#A1A1AA] hover:text-white'
              }`}
            >
              {filter.label}
            </button>
          );
        })}
      </div>

      {/* Media Grid View (like pinned threads grid) */}
      <div className="flex-1 px-4 py-3">
        {filteredMedia.length === 0 ? (
          <div className="py-24 flex flex-col items-center justify-center text-center px-6">
            <Film className="w-12 h-12 text-[#27272A] mb-3" />
            <p className="text-sm font-medium text-[#A1A1AA]">
              No shared media found in this category
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {filteredMedia.map(msg => (
              <MediaGridCard
                key={msg.id}
                message={msg}
                formatTimestamp={formatTimestamp}
                onCardClick={() => setInspectingMedia(msg)}
                onShowInChat={() => onShowInChat(msg.conversationId)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Media Inspection Modal */}
      {inspectingMedia && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setInspectingMedia(null)}
        >
          <div
            className="w-full max-w-sm rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-5 shadow-2xl animate-in zoom-in-95"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
              <h4 className="font-bold text-sm text-white font-mono truncate max-w-[200px]">
                {inspectingMedia.attachmentTitle || inspectingMedia.text}
              </h4>
              <button
                onClick={() => setInspectingMedia(null)}
                className="text-[#71717A] hover:text-white text-xs font-mono"
              >
                Close
              </button>
            </div>

            {/* Media Preview Box */}
            <div className="my-4 rounded-2xl overflow-hidden bg-[#141418] border border-[#27272A] flex items-center justify-center min-h-[160px]">
              {inspectingMedia.attachmentType === 'IMAGE' ? (
                <img
                  src={inspectingMedia.attachmentUri || 'https://images.unsplash.com/photo-1546874177-9e664107314e?w=800'}
                  alt={inspectingMedia.attachmentTitle || 'Photo'}
                  className="w-full h-44 object-cover"
                />
              ) : inspectingMedia.attachmentType === 'AUDIO' ? (
                <div className="flex flex-col items-center gap-2 p-6">
                  <div className="w-12 h-12 rounded-full bg-[#EF4444]/20 text-[#EF4444] flex items-center justify-center">
                    <Mic className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-mono text-white">Voice Memo (0:18)</span>
                </div>
              ) : inspectingMedia.attachmentType === 'LOCATION' ? (
                <div className="flex flex-col items-center gap-2 p-6">
                  <div className="w-12 h-12 rounded-full bg-[#F59E0B]/20 text-[#F59E0B] flex items-center justify-center">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-mono text-white text-center">
                    {inspectingMedia.text}
                  </span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 p-6">
                  <div className="w-12 h-12 rounded-full bg-[#A855F7]/20 text-[#A855F7] flex items-center justify-center">
                    <FileText className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-mono text-white">Document File</span>
                </div>
              )}
            </div>

            <div className="space-y-1 text-xs font-mono text-[#A1A1AA] mb-4">
              <div>Sender: <span className="text-white">{inspectingMedia.sender}</span></div>
              <div>Timestamp: <span className="text-white">{formatTimestamp(inspectingMedia.timestamp)}</span></div>
              <div>Protocol: <span className="text-[#06B6D4]">{inspectingMedia.protocol}</span></div>
            </div>

            <button
              onClick={() => {
                onShowInChat(inspectingMedia.conversationId);
                setInspectingMedia(null);
              }}
              className="w-full py-2.5 rounded-xl bg-[#06B6D4] text-black font-bold text-xs font-mono flex items-center justify-center gap-1.5 hover:bg-[#22d3ee] transition-colors"
            >
              <span>Show in Chat</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

interface MediaGridCardProps {
  message: MessageEntity;
  formatTimestamp: (ts: number) => string;
  onCardClick: () => void;
  onShowInChat: () => void;
}

const MediaGridCard: React.FC<MediaGridCardProps> = ({
  message,
  formatTimestamp,
  onCardClick,
  onShowInChat,
}) => {
  const getMediaMeta = () => {
    switch (message.attachmentType) {
      case 'IMAGE':
        return { icon: Image, color: '#06B6D4', label: 'Photo' };
      case 'AUDIO':
        return { icon: Mic, color: '#EF4444', label: 'Audio' };
      case 'LOCATION':
        return { icon: MapPin, color: '#F59E0B', label: 'Location' };
      default:
        return { icon: FileText, color: '#A855F7', label: 'Document' };
    }
  };

  const meta = getMediaMeta();
  const IconComp = meta.icon;

  return (
    <div
      data-testid={`media_item_${message.id}`}
      onClick={onCardClick}
      className="rounded-2xl bg-[#0A0A0C] border border-[#1E1E22] hover:border-[#06B6D4] p-3 flex flex-col justify-between cursor-pointer transition-all active:scale-[0.98] group"
    >
      {/* Top Visual Box */}
      <div className="w-full h-24 rounded-xl overflow-hidden bg-[#141418] border border-white/5 flex items-center justify-center relative mb-2">
        {message.attachmentType === 'IMAGE' ? (
          <img
            src={message.attachmentUri || 'https://images.unsplash.com/photo-1546874177-9e664107314e?w=800'}
            alt="Media thumbnail"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ backgroundColor: `${meta.color}20`, color: meta.color }}
          >
            <IconComp className="w-5 h-5" />
          </div>
        )}

        {/* Small Type Pip */}
        <span
          className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded bg-black/80 font-mono text-[9px] font-bold"
          style={{ color: meta.color }}
        >
          {meta.label}
        </span>
      </div>

      {/* Info Content */}
      <div className="min-w-0">
        <h4 className="font-bold text-xs text-white truncate">
          {message.attachmentTitle || message.text}
        </h4>
        <div className="flex items-center justify-between text-[10px] text-[#A1A1AA] font-mono mt-1">
          <span className="truncate">{message.sender}</span>
          <span className="text-[#06B6D4] text-[9px] font-bold ml-1">
            {message.protocol}
          </span>
        </div>
      </div>
    </div>
  );
};
