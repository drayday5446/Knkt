import React, { useState } from 'react';
import { useMessaging } from '../context/MessagingContext';
import { SwipeRightAction, SWIPE_RIGHT_ACTIONS } from '../types';
import {
  Archive,
  Trash2,
  Shield,
  Check,
  RotateCcw,
  Sparkles,
  Smartphone,
  X,
} from 'lucide-react';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { HapticHelper } from '../utils/haptics';

interface SettingsScreenProps {
  onOpenSecurityVault: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onOpenSecurityVault,
}) => {
  const {
    conversations,
    themePreferences,
    updateThemePreferences,
    toggleArchive,
    restoreFromTrash,
    emptyTrash,
  } = useMessaging();

  const [showArchiveModal, setShowArchiveModal] = useState(false);
  const [showTrashModal, setShowTrashModal] = useState(false);
  const [showEmptyTrashConfirm, setShowEmptyTrashConfirm] = useState(false);
  const [isDefaultApp, setIsDefaultApp] = useState(true);

  const archivedList = conversations.filter(c => c.isArchived && !c.isTrash);
  const trashList = conversations.filter(c => c.isTrash);

  const accentSwatches = [
    '#06B6D4', // Neon Cyan
    '#3B82F6', // Royal Blue
    '#10B981', // Emerald
    '#A855F7', // Neon Purple
    '#F97316', // Vibrant Coral
    '#EC4899', // Hot Pink
  ];

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col pb-36">
      {/* Top Header */}
      <div className="w-full pt-4 pb-2 px-4 border-b border-[#141418] bg-black/90 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KnktCmdChatIcon size={24} glow={true} accentColor="#06B6D4" />
            <div className="flex items-center">
              <span className="font-mono text-sm font-bold text-[#06B6D4] mr-1">&gt;</span>
              <span className="font-mono text-[14px] font-extrabold tracking-[0.18em] text-white">
                KNKT.sh
              </span>
              <span className="ml-2 px-1.5 py-0.5 rounded bg-[#090D12] border border-[#06B6D4]/30 font-mono text-[9px] text-[#06B6D4] font-semibold">
                settings
              </span>
            </div>
          </div>
          <span className="text-xs font-mono text-[#10B981]">
            SYS::READY
          </span>
        </div>
        <div className="flex items-center justify-between text-[10px] font-mono text-[#71717A] mt-1.5 pt-1 border-t border-[#141418]">
          <span>usr@knkt:~/config$ sudo knkt-ctl</span>
          <span>One UI 9.0 OLED</span>
        </div>
      </div>

      <div className="flex-1 px-4 space-y-5 mt-2">
        {/* Default Messaging App & Samsung Galaxy S26 Optimization */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            DEFAULT MESSAGING APP
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-white">KNKT Messenger</h4>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[9px] font-mono font-bold ${
                      isDefaultApp
                        ? 'bg-[#10B981]/20 text-[#10B981]'
                        : 'bg-[#27272A] text-[#A1A1AA]'
                    }`}
                  >
                    {isDefaultApp ? 'ACTIVE DEFAULT' : 'STANDBY'}
                  </span>
                </div>
                <p className="text-xs text-[#A1A1AA] mt-1 leading-relaxed">
                  Carrier SMS, MMS, & RCS protocols ready for Samsung Galaxy S26 base model.
                </p>
              </div>
            </div>

            <button
              data-testid="set_default_sms_app_btn"
              onClick={() => {
                setIsDefaultApp(!isDefaultApp);
                HapticHelper.reactionClick();
              }}
              className={`w-full py-2.5 rounded-xl font-bold text-xs mt-3.5 transition-colors ${
                isDefaultApp
                  ? 'bg-[#18181B] text-[#10B981] border border-[#27272A]'
                  : 'bg-[#06B6D4] text-black hover:bg-[#22d3ee]'
              }`}
            >
              {isDefaultApp
                ? 'Configured as Default SMS App ✓'
                : 'Set KNKT as Default SMS App'}
            </button>

            {/* Android Home Screen / WebAPK Install info */}
            <div className="mt-3 p-3 rounded-xl bg-[#141418] border border-[#27272A] text-xs">
              <div className="flex items-center justify-between text-white font-mono font-bold mb-1">
                <span className="text-[#06B6D4]">📱 INSTALL TO ANDROID:</span>
                <span className="text-[10px] text-[#10B981]">STANDALONE</span>
              </div>
              <p className="text-[11px] text-[#A1A1AA] leading-relaxed">
                Open in Chrome or Samsung Internet, tap <strong className="text-white">⋮ &gt; Install app</strong> (or &quot;Add to Home screen&quot;). Android creates a native WebAPK icon on your home screen with pure OLED black splash and full-screen standalone execution.
              </p>
            </div>

            {/* Features Badges row */}
            <div className="flex items-center gap-2 mt-3 overflow-x-auto no-scrollbar">
              {['Samsung One UI 9', 'Dynamic AMOLED 120Hz', 'Multi-Window / Pop-up'].map(tag => (
                <span
                  key={tag}
                  className="px-2 py-0.5 rounded-md bg-[#141418] border border-[#27272A] text-[9px] text-[#71717A] font-mono shrink-0"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Message Management (Archive & Trash sections) */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            MESSAGE MANAGEMENT
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-2 divide-y divide-[#1A1A20]">
            {/* Archive Row */}
            <div
              data-testid="settings_archive_entry"
              onClick={() => {
                HapticHelper.reactionClick();
                setShowArchiveModal(true);
              }}
              className="p-3 flex items-center justify-between cursor-pointer hover:bg-white/[0.02] rounded-xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#F59E0B]/15 text-[#F59E0B] flex items-center justify-center">
                  <Archive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Archived Chats</h4>
                  <p className="text-[11px] text-[#A1A1AA]">
                    {archivedList.length} conversations hidden from main lists
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-[#06B6D4]">Manage</span>
            </div>

            {/* Trash Row */}
            <div
              data-testid="settings_trash_entry"
              onClick={() => {
                HapticHelper.reactionClick();
                setShowTrashModal(true);
              }}
              className="p-3 flex items-center justify-between cursor-pointer hover:bg-white/[0.02] rounded-xl transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#EF4444]/15 text-[#EF4444] flex items-center justify-center">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">Trash Bin</h4>
                  <p className="text-[11px] text-[#A1A1AA]">
                    {trashList.length} soft-deleted chats
                  </p>
                </div>
              </div>
              <span className="text-xs font-bold text-[#EF4444]">Manage</span>
            </div>
          </div>
        </div>

        {/* Customizable Right Swipe Gesture */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            SWIPE GESTURES
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-4">
            <div className="mb-3">
              <h4 className="font-bold text-sm text-white">Right Swipe Action</h4>
              <p className="text-xs text-[#A1A1AA]">Left swipe always peeks/enters the chat</p>
            </div>

            <div className="space-y-2">
              {SWIPE_RIGHT_ACTIONS.map(action => {
                const isSelected = themePreferences.swipeRightAction === action.type;
                return (
                  <div
                    key={action.type}
                    data-testid={`swipe_action_${action.type.toLowerCase()}`}
                    onClick={() => {
                      updateThemePreferences(p => ({ ...p, swipeRightAction: action.type }));
                      HapticHelper.reactionClick();
                    }}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-[#141418] border-[#06B6D4]'
                        : 'bg-transparent border-[#222226] hover:border-[#2E2E36]'
                    }`}
                  >
                    <div>
                      <span className={`text-xs block ${isSelected ? 'font-bold text-white' : 'text-white/80'}`}>
                        {action.displayName}
                      </span>
                      <span className="text-[11px] text-[#71717A]">{action.iconDescription}</span>
                    </div>

                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        isSelected ? 'border-[#06B6D4] bg-[#06B6D4]' : 'border-[#52525B]'
                      }`}
                    >
                      {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Visual OLED Theming & Accents */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            OLED THEME & ACCENTS
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-4">
            <h4 className="font-bold text-xs text-white mb-2.5">
              Material & System Accent Colors
            </h4>
            <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
              {accentSwatches.map(hex => {
                const isSelected = themePreferences.customAccentHex.toLowerCase() === hex.toLowerCase();
                return (
                  <button
                    key={hex}
                    data-testid={`settings_accent_${hex}`}
                    onClick={() => {
                      updateThemePreferences(p => ({ ...p, customAccentHex: hex }));
                      HapticHelper.reactionClick();
                    }}
                    className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-transform ${
                      isSelected ? 'ring-2 ring-white scale-110' : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: hex }}
                  >
                    {isSelected && <Check className="w-4 h-4 text-black stroke-[3]" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-4 mt-4 border-t border-[#1E1E24] flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-xs text-white">Pure Black OLED Backgrounds</h5>
                <p className="text-[11px] text-[#A1A1AA]">True #000000 black with zero gray bleeding</p>
              </div>
              <button
                data-testid="oled_black_switch"
                onClick={() => {
                  updateThemePreferences(p => ({ ...p, isOledBlack: !p.isOledBlack }));
                  HapticHelper.reactionClick();
                }}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  themePreferences.isOledBlack ? 'bg-[#06B6D4]' : 'bg-[#27272A]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-black transition-transform ${
                    themePreferences.isOledBlack ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Bubble Corner Radius */}
            <div className="pt-4 mt-4 border-t border-[#1E1E24]">
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-semibold text-xs text-white">Bubble Corner Radius</h5>
                <span className="font-mono text-xs text-[#06B6D4] font-bold">
                  {themePreferences.bubbleRadius || 20}px
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { label: 'Sharp', val: 6 },
                  { label: 'Compact', val: 12 },
                  { label: 'Squircle', val: 20 },
                  { label: 'Round', val: 28 },
                ].map(r => {
                  const isSelected = (themePreferences.bubbleRadius || 20) === r.val;
                  return (
                    <button
                      key={r.val}
                      onClick={() => {
                        updateThemePreferences(p => ({ ...p, bubbleRadius: r.val }));
                        HapticHelper.reactionClick();
                      }}
                      className={`py-1.5 px-2 rounded-xl text-xs font-mono border transition-all ${
                        isSelected
                          ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4] font-bold'
                          : 'bg-[#141418] border-[#27272A] text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      {r.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Message Tail Style */}
            <div className="pt-4 mt-4 border-t border-[#1E1E24]">
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-semibold text-xs text-white">Message Tail Style</h5>
                <span className="font-mono text-[10px] text-[#A1A1AA]">
                  {themePreferences.bubbleTailStyle || 'CLASSIC'}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: 'CLASSIC', label: 'Classic' },
                  { id: 'SUBTLE', label: 'Micro' },
                  { id: 'CORNER_CUT', label: 'Cut' },
                  { id: 'NONE', label: 'None' },
                ].map(t => {
                  const isSelected = (themePreferences.bubbleTailStyle || 'CLASSIC') === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => {
                        updateThemePreferences(p => ({
                          ...p,
                          bubbleTailStyle: t.id as any,
                        }));
                        HapticHelper.reactionClick();
                      }}
                      className={`py-1.5 px-2 rounded-xl text-xs font-mono border transition-all ${
                        isSelected
                          ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4] font-bold'
                          : 'bg-[#141418] border-[#27272A] text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      {t.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Notifications & Read Receipts */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            NOTIFICATIONS & PRIVACY
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-4 space-y-3.5">
            {/* Read Receipts Switch */}
            <div className="flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-xs text-white">Send Read Receipts</h5>
                <p className="text-[11px] text-[#A1A1AA]">Show glowing checkmarks (✓✓) when messages are viewed</p>
              </div>
              <button
                data-testid="read_receipts_switch"
                onClick={() => {
                  updateThemePreferences(p => ({
                    ...p,
                    readReceiptsEnabled: !p.readReceiptsEnabled,
                  }));
                  HapticHelper.reactionClick();
                }}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  themePreferences.readReceiptsEnabled ? 'bg-[#06B6D4]' : 'bg-[#27272A]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-black transition-transform ${
                    themePreferences.readReceiptsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Quick Reply Switch */}
            <div className="pt-3 border-t border-[#1E1E24] flex items-center justify-between">
              <div>
                <h5 className="font-semibold text-xs text-white">Quick Reply in Notifications</h5>
                <p className="text-[11px] text-[#A1A1AA]">Direct reply actions with inline text input</p>
              </div>
              <button
                data-testid="quick_reply_switch"
                onClick={() => {
                  updateThemePreferences(p => ({ ...p, quickReplyEnabled: !p.quickReplyEnabled }));
                  HapticHelper.reactionClick();
                }}
                className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                  themePreferences.quickReplyEnabled ? 'bg-[#06B6D4]' : 'bg-[#27272A]'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-black transition-transform ${
                    themePreferences.quickReplyEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            <div className="pt-3 border-t border-[#1E1E24] flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <h5 className="font-semibold text-xs text-white">One UI Multi-Window & Pop-Up View</h5>
                <p className="text-[11px] text-[#A1A1AA]">Optimized for split screen, floating pop-up cards and DeX</p>
              </div>
            </div>
          </div>
        </div>

        {/* Security Vault Entry */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            SECURITY & ENCRYPTION
          </span>
          <div
            data-testid="open_vault_card"
            onClick={() => {
              HapticHelper.reactionClick();
              onOpenSecurityVault();
            }}
            className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] hover:border-[#10B981]/50 p-4 flex items-center justify-between cursor-pointer transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center shrink-0">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">E2EE Cryptographic Vault</h4>
                <p className="text-xs text-[#A1A1AA]">Curve25519 & AES-256-GCM session keys</p>
              </div>
            </div>
            <span className="text-xs font-bold text-[#10B981]">View →</span>
          </div>
        </div>
      </div>

      {/* Archived Conversations Modal */}
      {showArchiveModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setShowArchiveModal(false)}
        >
          <div
            className="w-full max-w-md rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl max-h-[80vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
              <h3 className="font-bold text-white text-base">
                Archived Conversations ({archivedList.length})
              </h3>
              <button onClick={() => setShowArchiveModal(false)} className="text-[#71717A] hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 my-4">
              {archivedList.length === 0 ? (
                <p className="text-xs text-[#A1A1AA] py-6 text-center">
                  No conversations currently archived.
                </p>
              ) : (
                archivedList.map(conv => (
                  <div
                    key={conv.id}
                    className="p-3 rounded-xl bg-[#141418] border border-[#27272A] flex items-center justify-between"
                  >
                    <div className="min-w-0 pr-2">
                      <h5 className="font-bold text-xs text-white truncate">{conv.recipientName}</h5>
                      <p className="text-[11px] text-[#A1A1AA] truncate">{conv.lastMessage}</p>
                    </div>
                    <button
                      data-testid={`unarchive_btn_${conv.id}`}
                      onClick={() => {
                        toggleArchive(conv.id);
                        HapticHelper.reactionClick();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#222228] hover:bg-[#2A2A32] text-xs font-semibold text-[#06B6D4] shrink-0"
                    >
                      Unarchive
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-[#1E1E24]">
              <button
                onClick={() => setShowArchiveModal(false)}
                className="px-5 py-2 rounded-xl bg-[#18181B] text-white text-xs font-semibold hover:bg-[#222228]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Trash Bin Modal */}
      {showTrashModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in"
          onClick={() => setShowTrashModal(false)}
        >
          <div
            className="w-full max-w-md rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl max-h-[80vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
              <h3 className="font-bold text-white text-base">
                Trash Bin ({trashList.length})
              </h3>
              {trashList.length > 0 && (
                <button
                  onClick={() => setShowEmptyTrashConfirm(true)}
                  className="text-xs font-bold text-[#EF4444] hover:underline"
                >
                  Empty
                </button>
              )}
            </div>

            <div className="space-y-2 my-4">
              {trashList.length === 0 ? (
                <p className="text-xs text-[#A1A1AA] py-6 text-center">Trash is empty.</p>
              ) : (
                trashList.map(conv => (
                  <div
                    key={conv.id}
                    className="p-3 rounded-xl bg-[#141418] border border-[#27272A] flex items-center justify-between"
                  >
                    <div className="min-w-0 pr-2">
                      <h5 className="font-bold text-xs text-white truncate">{conv.recipientName}</h5>
                      <p className="text-[11px] text-[#A1A1AA] truncate">{conv.lastMessage}</p>
                    </div>
                    <button
                      data-testid={`restore_trash_btn_${conv.id}`}
                      onClick={() => {
                        restoreFromTrash(conv.id);
                        HapticHelper.reactionClick();
                      }}
                      className="px-2.5 py-1 rounded-lg bg-[#222228] hover:bg-[#2A2A32] text-xs font-semibold text-[#10B981] flex items-center gap-1 shrink-0"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Restore</span>
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-[#1E1E24]">
              <button
                onClick={() => setShowTrashModal(false)}
                className="px-5 py-2 rounded-xl bg-[#18181B] text-white text-xs font-semibold hover:bg-[#222228]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Permanently Empty Trash Confirm */}
      {showEmptyTrashConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
          onClick={() => setShowEmptyTrashConfirm(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-[#0F0F14] border border-[#27272A] p-5 shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            <h4 className="font-bold text-white text-base">Permanently Empty Trash?</h4>
            <p className="text-xs text-[#A1A1AA] my-2 leading-relaxed">
              All conversations in Trash will be permanently deleted and cannot be recovered.
            </p>
            <div className="flex items-center justify-end gap-2.5 mt-4">
              <button
                onClick={() => setShowEmptyTrashConfirm(false)}
                className="px-4 py-2 text-xs font-semibold text-[#A1A1AA] hover:text-white"
              >
                Cancel
              </button>
              <button
                data-testid="confirm_empty_trash_btn"
                onClick={() => {
                  emptyTrash();
                  setShowEmptyTrashConfirm(false);
                  setShowTrashModal(false);
                  HapticHelper.reactionClick();
                }}
                className="px-4 py-2 rounded-xl bg-[#EF4444] text-white font-bold text-xs hover:bg-[#dc2626]"
              >
                Empty Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
