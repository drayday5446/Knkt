import React, { useState, useEffect, useRef } from 'react';
import { useMessaging } from '../context/MessagingContext';
import {
  MessageProtocolType,
  MessageEntity,
  ConversationEntity,
  BubbleShapeType,
} from '../types';
import {
  ArrowLeft,
  Shield,
  Film,
  Lock,
  LockOpen,
  ChevronUp,
  ChevronDown,
  Palette,
  Plus,
  Mic,
  Send,
  Play,
  ExternalLink,
  MapPin,
  Check,
  CheckCheck,
  Clock,
  Copy,
} from 'lucide-react';
import { CryptoInspectorDialog } from '../components/CryptoInspectorDialog';
import { SafetyNumberDialog } from '../components/SafetyNumberDialog';
import { AttachmentPickerSheet } from '../components/AttachmentPickerSheet';
import { ThreadCustomizerSheet } from '../components/ThreadCustomizerSheet';
import { ScheduleSendModal } from '../components/ScheduleSendModal';
import { TypingIndicator } from '../components/TypingIndicator';
import { ReactionSelector } from '../components/ReactionSelector';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { HapticHelper } from '../utils/haptics';

interface ChatThreadScreenProps {
  conversationId: number;
  onBackClick: () => void;
}

export const ChatThreadScreen: React.FC<ChatThreadScreenProps> = ({
  conversationId,
  onBackClick,
}) => {
  const {
    conversations,
    messages,
    themePreferences,
    typingStatus,
    sendMessage,
    updateReaction,
    updateProtocol,
    updateE2EE,
    updateCustomTheming,
    markConversationRead,
    verifyContact,
  } = useMessaging();

  const conversation = conversations.find(c => c.id === conversationId);
  const threadMessages = messages.filter(m => m.conversationId === conversationId);
  const typingName = typingStatus[conversationId];

  const [inputText, setInputText] = useState('');
  const [activeProtocol, setActiveProtocol] = useState<MessageProtocolType>(
    conversation?.activeProtocol || 'RCS'
  );
  const [isE2EEActive, setIsE2EEActive] = useState(conversation?.isE2EE ?? true);

  // Bottom toolbar bubble expandable state
  const [isToolbarBubbleExpanded, setIsToolbarBubbleExpanded] = useState(false);
  const [showCustomizerSheet, setShowCustomizerSheet] = useState(false);
  const [showAttachmentSheet, setShowAttachmentSheet] = useState(false);
  const [showSafetyNumberDialog, setShowSafetyNumberDialog] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [inspectingMessage, setInspectingMessage] = useState<MessageEntity | null>(null);
  const [reactingToMessageId, setReactingToMessageId] = useState<number | null>(null);
  const [selectedMessageForAction, setSelectedMessageForAction] = useState<MessageEntity | null>(null);

  // Media Window Sliding & Peek State: 0 = hidden, 1 = fully open
  // Swiping left peeks the media page and lets it slide on top of the thread
  const [mediaPeekProgress, setMediaPeekProgress] = useState(0);
  const [isMediaWindowOpen, setIsMediaWindowOpen] = useState(false);
  const [selectedMediaCategory, setSelectedMediaCategory] = useState<string>('ALL');

  // Swipe right from within chat to return to main page
  const [chatBackOffset, setChatBackOffset] = useState(0);

  // Gesture tracking refs
  const touchStartXRef = useRef(0);
  const touchCurrentXRef = useRef(0);
  const isDraggingHorizRef = useRef(false);
  const sendBtnTimerRef = useRef<NodeJS.Timeout | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (conversation) {
      markConversationRead(conversation.id);
      setActiveProtocol(conversation.activeProtocol);
      setIsE2EEActive(conversation.isE2EE);
    }
  }, [conversation?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [threadMessages.length, typingName]);

  if (!conversation) {
    return (
      <div className="w-full h-screen bg-black text-white flex items-center justify-center font-mono">
        <p className="text-sm text-[#A1A1AA]">&gt; ERR::CONV_NOT_FOUND</p>
      </div>
    );
  }

  // Parse group bubble config (stores "Alex Rivera|#06B6D4|ROUNDED;...")
  const groupBubbleMap: Record<string, { color: string; shape: BubbleShapeType }> = {};
  if (conversation.groupBubbleConfigJson) {
    conversation.groupBubbleConfigJson.split(';').forEach(entry => {
      const parts = entry.split('|');
      if (parts.length >= 3) {
        groupBubbleMap[parts[0]] = {
          color: parts[1],
          shape: (parts[2] as BubbleShapeType) || 'ROUNDED',
        };
      }
    });
  }

  // Minimal protocol pip color
  const minimalProtocolPipColor = isE2EEActive
    ? '#06B6D4' // Cyan (E2EE)
    : activeProtocol === 'MMS'
    ? '#0284C7'
    : '#64748B'; // Slate Gray

  const handleSend = () => {
    if (!inputText.trim()) return;
    const textToSend = inputText.trim();
    setInputText('');
    sendMessage(conversation.id, textToSend, activeProtocol, isE2EEActive);
  };

  const handleScheduleSend = (scheduledTimestamp: number) => {
    if (!inputText.trim()) return;
    const textToSend = inputText.trim();
    setInputText('');
    setShowScheduleModal(false);
    sendMessage(
      conversation.id,
      textToSend,
      activeProtocol,
      isE2EEActive,
      undefined,
      undefined,
      scheduledTimestamp
    );
  };

  const startSendBtnLongPress = () => {
    sendBtnTimerRef.current = setTimeout(() => {
      if (inputText.trim()) {
        HapticHelper.longPress();
        setShowScheduleModal(true);
      }
    }, 450);
  };

  const cancelSendBtnLongPress = () => {
    if (sendBtnTimerRef.current) {
      clearTimeout(sendBtnTimerRef.current);
      sendBtnTimerRef.current = null;
    }
  };

  const getBubbleStyle = (isFromUser: boolean, sender: string) => {
    if (isFromUser) {
      const color = conversation.customUserBubbleColor || '#06B6D4';
      const shape = conversation.customUserBubbleShape || themePreferences.defaultBubbleShape || 'ROUNDED';
      return { color, shape };
    } else {
      if (conversation.isGroup && groupBubbleMap[sender]) {
        return groupBubbleMap[sender];
      }
      const color = conversation.customPeerBubbleColor || '#18181B';
      const shape = conversation.customPeerBubbleShape || themePreferences.defaultBubbleShape || 'ROUNDED';
      return { color, shape };
    }
  };

  const getDynamicRadiusStyle = (isFromUser: boolean, shape: BubbleShapeType): React.CSSProperties => {
    const r = themePreferences.bubbleRadius || 20;
    const tailStyle = themePreferences.bubbleTailStyle || 'CLASSIC';

    if (shape === 'RECTANGULAR') {
      return { borderRadius: '6px' };
    }
    if (shape === 'PILL') {
      return { borderRadius: '28px' };
    }

    if (tailStyle === 'NONE') {
      return { borderRadius: `${r}px` };
    }
    if (tailStyle === 'CORNER_CUT') {
      return isFromUser
        ? { borderRadius: `${r}px ${r}px 0px ${r}px` }
        : { borderRadius: `${r}px ${r}px ${r}px 0px` };
    }
    if (tailStyle === 'SUBTLE') {
      return isFromUser
        ? { borderRadius: `${r}px ${r}px ${Math.max(4, r / 3)}px ${r}px` }
        : { borderRadius: `${r}px ${r}px ${r}px ${Math.max(4, r / 3)}px` };
    }
    return isFromUser
      ? { borderRadius: `${r}px ${r}px 3px ${r}px` }
      : { borderRadius: `${r}px ${r}px ${r}px 3px` };
  };

  const getTextColor = (hexColor: string): string => {
    const cleanHex = hexColor.replace('#', '');
    const num = parseInt(cleanHex, 16);
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.5 ? '#000000' : '#FFFFFF';
  };

  const formatTime = (ts: number) => {
    return new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  // Filter in-thread media
  const threadMediaMessages = threadMessages.filter(m => !!m.attachmentType);
  const filteredThreadMedia = threadMediaMessages.filter(m => {
    if (selectedMediaCategory === 'ALL') return true;
    if (selectedMediaCategory === 'PHOTOS') return m.attachmentType === 'IMAGE';
    if (selectedMediaCategory === 'AUDIO') return m.attachmentType === 'AUDIO';
    if (selectedMediaCategory === 'LOCATION') return m.attachmentType === 'LOCATION';
    return (
      m.attachmentType !== 'IMAGE' &&
      m.attachmentType !== 'AUDIO' &&
      m.attachmentType !== 'LOCATION'
    );
  });

  // Touch handlers for interactive peek of Media Page Window
  const handleTouchStart = (clientX: number) => {
    touchStartXRef.current = clientX;
    touchCurrentXRef.current = clientX;
    isDraggingHorizRef.current = true;
  };

  const handleTouchMove = (clientX: number) => {
    if (!isDraggingHorizRef.current) return;
    touchCurrentXRef.current = clientX;
    const delta = clientX - touchStartXRef.current;

    if (!isMediaWindowOpen) {
      if (delta < 0) {
        // Swiping left: peek media window
        const progress = Math.min(1, Math.abs(delta) / 280);
        setMediaPeekProgress(progress);
        setChatBackOffset(0);
      } else if (delta > 0) {
        // Swiping right: translate chat screen back to main page!
        setChatBackOffset(Math.max(0, delta));
        setMediaPeekProgress(0);
      }
    } else {
      // Swiping right from within media window peeks back to thread!
      if (delta > 0) {
        const progress = Math.max(0, 1 - delta / 280);
        setMediaPeekProgress(progress);
      }
    }
  };

  const handleTouchEnd = () => {
    if (!isDraggingHorizRef.current) return;
    isDraggingHorizRef.current = false;
    const delta = touchCurrentXRef.current - touchStartXRef.current;

    if (!isMediaWindowOpen) {
      if (delta < -75 || mediaPeekProgress > 0.25) {
        HapticHelper.gestureSwipe();
        setIsMediaWindowOpen(true);
        setMediaPeekProgress(1);
      } else if (delta > 85 || chatBackOffset > 85) {
        // Swiped right far enough -> Return to homepage!
        HapticHelper.gestureSwipe();
        onBackClick();
      } else {
        setMediaPeekProgress(0);
        setChatBackOffset(0);
      }
    } else {
      if (delta > 75 || mediaPeekProgress < 0.75) {
        HapticHelper.gestureSwipe();
        setIsMediaWindowOpen(false);
        setMediaPeekProgress(0);
      } else {
        setMediaPeekProgress(1);
      }
    }
  };

  const effectiveMediaWindowVisible = isMediaWindowOpen || mediaPeekProgress > 0.02;
  const mediaWindowTranslate = `translateX(${(1 - mediaPeekProgress) * 100}%)`;
  const availableEmojis = ['❤️', '👍', '😂', '😮', '😢', '🔥', '👏', '🚀'];

  return (
    <div
      className="fixed inset-0 z-30 bg-black text-white flex flex-col overflow-hidden select-none"
      style={{
        transform: `translateX(${chatBackOffset}px)`,
        transition: isDraggingHorizRef.current ? 'none' : 'transform 0.2s ease-out',
      }}
      onTouchStart={e => handleTouchStart(e.touches[0].clientX)}
      onTouchMove={e => handleTouchMove(e.touches[0].clientX)}
      onTouchEnd={handleTouchEnd}
      onMouseDown={e => handleTouchStart(e.clientX)}
      onMouseMove={e => {
        if (isDraggingHorizRef.current) handleTouchMove(e.clientX);
      }}
      onMouseUp={handleTouchEnd}
    >
      {/* Top Bar: Clean and minimal without KNKT at top right */}
      <div className="w-full pt-4 pb-2.5 px-4 bg-black border-b border-[#141418] flex items-center justify-between shrink-0 z-10">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBackClick}
            className="p-1.5 -ml-1.5 rounded-full hover:bg-white/10 text-white"
            title="Back to conversation list"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Profile Avatar */}
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs text-white shrink-0 shadow-sm"
            style={{ backgroundColor: conversation.avatarColorHex }}
          >
            {conversation.isGroup
              ? '👥'
              : (conversation.recipientName[0] || 'K').toUpperCase()}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h2 className="font-bold text-[15px] text-white truncate leading-tight">
                {conversation.recipientName}
              </h2>
              {isE2EEActive && (
                <Shield className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
              )}
            </div>

            <div className="flex items-center gap-1.5 font-mono">
              <span
                className="w-1.5 h-1.5 rounded-full inline-block shrink-0"
                style={{ backgroundColor: minimalProtocolPipColor }}
              />
              <span className="text-[11px] text-[#A1A1AA] truncate">
                {typingName
                  ? `${typingName} is typing...`
                  : `${activeProtocol} • ${
                      conversation.isGroup
                        ? `${conversation.groupParticipants?.split(',').length || 3} members`
                        : conversation.recipientPhone
                    }`}
              </span>
            </div>
          </div>
        </div>

        {/* Right actions: quick shared media access button with peek indicator */}
        <button
          data-testid="chat_top_media_btn"
          onClick={() => {
            HapticHelper.gestureSwipe();
            setIsMediaWindowOpen(true);
            setMediaPeekProgress(1);
          }}
          className="p-2 rounded-xl text-[#06B6D4] hover:bg-[#141418] transition-colors flex items-center gap-1"
          title="Open Shared Media Window"
        >
          <Film className="w-5 h-5" />
          <span className="text-[10px] font-mono font-bold hidden sm:inline">&lt; Media</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2.5">
        {threadMessages.map(msg => {
          const { color, shape } = getBubbleStyle(msg.isFromUser, msg.sender);
          const textColor = getTextColor(color);
          const dynamicRadius = getDynamicRadiusStyle(msg.isFromUser, shape);

          return (
            <div
              key={msg.id}
              data-testid={`bubble_${msg.id}`}
              className={`flex flex-col ${
                msg.isFromUser ? 'items-end' : 'items-start'
              }`}
            >
              {/* Group chat sender name */}
              {conversation.isGroup && !msg.isFromUser && (
                <span className="text-[11px] font-bold text-[#A1A1AA] pl-2 mb-0.5 font-mono">
                  {msg.sender}
                </span>
              )}

              {/* Message Bubble - with Long Press for Emoji Reactions */}
              <div
                onClick={() => setReactingToMessageId(msg.id)}
                onContextMenu={e => {
                  e.preventDefault();
                  HapticHelper.longPress();
                  setSelectedMessageForAction(msg);
                }}
                className="max-w-[82%] px-3.5 py-2 cursor-pointer transition-transform active:scale-[0.99] select-text relative shadow-sm"
                style={{ backgroundColor: color, ...dynamicRadius }}
              >
                {/* Media Attachment if present */}
                {msg.attachmentType && (
                  <div className="mb-2">
                    {msg.attachmentType === 'IMAGE' && (
                      <div className="rounded-xl overflow-hidden bg-black/40 border border-white/10 mb-1 max-w-[260px]">
                        <img
                          src={msg.attachmentUri || 'https://images.unsplash.com/photo-1546874177-9e664107314e?w=800'}
                          alt={msg.attachmentTitle || 'Photo'}
                          className="w-full h-32 object-cover"
                        />
                        <div className="p-1.5 text-[10px] font-mono truncate text-white/80">
                          📷 {msg.attachmentTitle || 'photo.jpg'}
                        </div>
                      </div>
                    )}
                    {msg.attachmentType === 'AUDIO' && (
                      <div className="flex items-center gap-2 p-2 rounded-xl bg-black/30 border border-white/10">
                        <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
                          <Play className="w-3.5 h-3.5 text-white" />
                        </div>
                        <span className="text-xs font-mono font-medium" style={{ color: textColor }}>
                          🎙️ {msg.attachmentTitle || 'Voice Memo'}
                        </span>
                      </div>
                    )}
                    {msg.attachmentType === 'LOCATION' && (
                      <div className="flex items-center gap-2 p-2 rounded-xl bg-black/30 border border-white/10">
                        <MapPin className="w-4 h-4 text-[#F59E0B]" />
                        <span className="text-xs font-semibold" style={{ color: textColor }}>
                          📍 {msg.text}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Message Text */}
                <p
                  className="text-sm leading-relaxed break-words"
                  style={{ color: textColor }}
                >
                  {msg.text}
                </p>

                {/* Timestamp, Scheduled Clock, Crypto Status & Checkmarks */}
                <div className="flex items-center justify-end gap-1.5 mt-1">
                  {msg.isScheduled && (
                    <span
                      title="Scheduled Send"
                      className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-[#F59E0B]"
                    >
                      <Clock className="w-3 h-3 text-[#F59E0B]" />
                      <span>Scheduled</span>
                    </span>
                  )}

                  {msg.isEncrypted && (
                    <button
                      data-testid={`bubble_crypto_${msg.id}`}
                      onClick={e => {
                        e.stopPropagation();
                        setInspectingMessage(msg);
                      }}
                      title="Inspect E2EE Cryptographic Packet"
                      className="p-0.5 rounded hover:bg-white/15"
                    >
                      <Lock className="w-2.5 h-2.5 opacity-80" style={{ color: textColor }} />
                    </button>
                  )}
                  <span
                    className="text-[10px] opacity-75 font-mono"
                    style={{ color: textColor }}
                  >
                    {formatTime(msg.timestamp)}
                  </span>

                  {/* Read Receipts with Checkmarks */}
                  {msg.isFromUser && (
                    <OledCheckmarkStatusIndicator
                      status={msg.status}
                      readReceiptsEnabled={themePreferences.readReceiptsEnabled}
                      textColor={textColor}
                      testId={`read_status_${msg.id}`}
                    />
                  )}
                </div>
              </div>

              {/* Floating Reaction Bubble beneath message text */}
              {msg.reaction && (
                <button
                  data-testid={`msg_reaction_${msg.id}`}
                  onClick={() => {
                    HapticHelper.reactionClick();
                    updateReaction(msg.id, null);
                  }}
                  className="mt-1 px-2 py-0.5 rounded-full bg-[#141418] border border-[#27272A] hover:border-[#06B6D4] text-xs shadow-md transition-transform active:scale-90 flex items-center gap-1"
                >
                  <span>{msg.reaction}</span>
                  <span className="text-[9px] font-mono text-[#71717A]">1</span>
                </button>
              )}
            </div>
          );
        })}

        {/* Dedicated Typing Indicator Component */}
        {typingName && (
          <div className="pt-1">
            <TypingIndicator name={typingName} />
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Section: Expandable Toolbar Bubble Just Above Text Box, followed ONLY by Text Field */}
      <div className="w-full bg-black p-3.5 pt-1 space-y-2 border-t border-[#141418] shrink-0 z-10">
        {/* Toolbar Bubble Just Above the Text Box */}
        <div
          data-testid="chat_bottom_toolbar_bubble"
          className="w-full rounded-[20px] bg-[#0D0D10] border border-[#27272A] p-2 transition-all"
        >
          {/* Header of toolbar bubble: shows minimal protocol pip + tap to expand/collapse */}
          <div
            onClick={() => setIsToolbarBubbleExpanded(!isToolbarBubbleExpanded)}
            className="flex items-center justify-between px-2 py-1 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <span
                className="w-2 h-2 rounded-full inline-block"
                style={{ backgroundColor: minimalProtocolPipColor }}
              />
              <span
                className="text-xs font-bold font-mono tracking-wide"
                style={{ color: minimalProtocolPipColor }}
              >
                {activeProtocol} {isE2EEActive && '• E2EE'}
              </span>
              <span className="text-[10px] text-[#71717A] ml-1 font-mono">
                {isToolbarBubbleExpanded ? 'tap to collapse' : 'tap for options'}
              </span>
            </div>

            <button className="text-[#A1A1AA] hover:text-white">
              {isToolbarBubbleExpanded ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Expanded Options */}
          {isToolbarBubbleExpanded && (
            <div className="pt-2.5 pb-1 border-t border-[#1E1E24] mt-1 space-y-2.5">
              {/* Protocol switchers & E2EE Toggle */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {(['SMS', 'MMS', 'RCS'] as MessageProtocolType[]).map(p => {
                    const isSelected = activeProtocol === p;
                    return (
                      <button
                        key={p}
                        data-testid={`proto_chip_${p.toLowerCase()}`}
                        onClick={() => {
                          setActiveProtocol(p);
                          if (p !== 'RCS') setIsE2EEActive(false);
                          updateProtocol(conversation.id, p);
                          if (p !== 'RCS') updateE2EE(conversation.id, false);
                          HapticHelper.reactionClick();
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                          isSelected
                            ? 'bg-[#06B6D4]/25 text-[#06B6D4] ring-1 ring-[#06B6D4]'
                            : 'bg-[#141418] text-[#A1A1AA] hover:text-white'
                        }`}
                      >
                        {p}
                      </button>
                    );
                  })}
                </div>

                {/* E2EE Lock Toggle */}
                <button
                  onClick={() => {
                    if (activeProtocol === 'RCS') {
                      const next = !isE2EEActive;
                      setIsE2EEActive(next);
                      updateE2EE(conversation.id, next);
                      HapticHelper.reactionClick();
                    }
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                    isE2EEActive
                      ? 'bg-[#10B981]/20 text-[#10B981] ring-1 ring-[#10B981]'
                      : 'bg-[#141418] text-[#71717A]'
                  }`}
                >
                  {isE2EEActive ? <Lock className="w-3 h-3" /> : <LockOpen className="w-3 h-3" />}
                  <span>{isE2EEActive ? 'E2EE' : 'Unencrypted'}</span>
                </button>
              </div>

              {/* Action Buttons: Customize, Add Media +, Voice Mic, System SMS */}
              <div className="flex items-center justify-between gap-2 pt-1">
                {/* Customize Button */}
                <button
                  data-testid="toolbar_customize_btn"
                  onClick={() => setShowCustomizerSheet(true)}
                  className="px-3 py-1.5 rounded-xl bg-[#06B6D4]/15 border border-[#06B6D4]/40 hover:bg-[#06B6D4]/25 text-[#06B6D4] font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>Customize</span>
                </button>

                <div className="flex items-center gap-2">
                  {/* Plus Button to add media */}
                  <button
                    data-testid="toolbar_attach_media_btn"
                    onClick={() => setShowAttachmentSheet(true)}
                    className="w-8 h-8 rounded-full bg-[#18181B] border border-[#27272A] hover:border-[#06B6D4] text-[#06B6D4] flex items-center justify-center transition-colors"
                    title="Attach Media"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                  </button>

                  {/* Schedule Send Button */}
                  <button
                    data-testid="toolbar_schedule_send_btn"
                    onClick={() => {
                      if (!inputText.trim()) {
                        setInputText('Hello! Scheduled check-in.');
                      }
                      setShowScheduleModal(true);
                    }}
                    className="w-8 h-8 rounded-full bg-[#18181B] border border-[#27272A] hover:border-[#06B6D4] text-[#F59E0B] flex items-center justify-center transition-colors"
                    title="Schedule Send"
                  >
                    <Clock className="w-3.5 h-3.5" />
                  </button>

                  {/* Microphone for voice memo */}
                  <button
                    data-testid="toolbar_mic_voice_btn"
                    onClick={() => {
                      sendMessage(
                        conversation.id,
                        'Voice Memo (0:14)',
                        activeProtocol,
                        isE2EEActive,
                        { type: 'AUDIO', title: 'Voice Memo (0:14)' }
                      );
                      HapticHelper.messageSend();
                    }}
                    className="w-8 h-8 rounded-full bg-[#18181B] border border-[#27272A] hover:border-[#06B6D4] text-[#06B6D4] flex items-center justify-center transition-colors"
                    title="Send Voice Memo"
                  >
                    <Mic className="w-4 h-4" />
                  </button>

                  {/* Shared Media peek button */}
                  <button
                    onClick={() => {
                      HapticHelper.gestureSwipe();
                      setIsMediaWindowOpen(true);
                      setMediaPeekProgress(1);
                    }}
                    className="w-8 h-8 rounded-full bg-[#18181B] border border-[#27272A] hover:border-[#06B6D4] text-[#06B6D4] flex items-center justify-center transition-colors"
                    title="Shared Media Window"
                  >
                    <Film className="w-3.5 h-3.5" />
                  </button>

                  {/* Carrier SMS Hand-off */}
                  <a
                    href={`sms:${conversation.recipientPhone}?body=${encodeURIComponent(inputText)}`}
                    className="w-8 h-8 rounded-full bg-[#18181B] border border-[#27272A] hover:border-white/40 text-[#A1A1AA] flex items-center justify-center transition-colors"
                    title="Open Carrier SMS"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Just below it: ONLY the text field with blinking CMD/terminal cursor */}
        <div
          className={`w-full rounded-[22px] bg-[#0A0A0D] border p-2 px-3.5 flex items-center gap-2 transition-colors ${
            inputText.trim() ? 'border-[#06B6D4]' : 'border-[#27272A]'
          }`}
        >
          {/* Terminal Prompt Symbol > */}
          <span className="font-mono font-bold text-[#06B6D4] text-sm">&gt;</span>

          <div
            data-testid="chat_input_text_field"
            className="flex-1 flex items-center min-w-0"
          >
            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder={
                activeProtocol === 'RCS'
                  ? isE2EEActive
                    ? 'Encrypted message...'
                    : 'RCS message...'
                  : activeProtocol === 'SMS'
                  ? 'Text message (SMS)...'
                  : 'Multimedia message...'
              }
              className="w-full bg-transparent text-white text-xs font-mono placeholder-[#52525B] outline-none"
            />
            {/* CMD Terminal Blinking Cursor */}
            <span
              data-testid="cmd_blinking_cursor"
              className="text-[#06B6D4] font-mono font-bold text-sm animate-cmd-blink select-none ml-0.5"
            >
              █
            </span>
          </div>

          {/* Send Button - with long press to schedule send! */}
          {inputText.trim() && (
            <button
              data-testid="chat_send_action_btn"
              onClick={handleSend}
              onContextMenu={e => {
                e.preventDefault();
                setShowScheduleModal(true);
              }}
              onTouchStart={startSendBtnLongPress}
              onTouchEnd={cancelSendBtnLongPress}
              onMouseDown={startSendBtnLongPress}
              onMouseUp={cancelSendBtnLongPress}
              onMouseLeave={cancelSendBtnLongPress}
              title="Click to send, long-press to schedule send"
              className="w-8 h-8 rounded-full bg-[#06B6D4] hover:bg-[#22d3ee] text-black flex items-center justify-center shrink-0 transition-transform active:scale-95 shadow-md"
            >
              <Send className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          )}
        </div>
      </div>

      {/* Dedicated In-Thread Media Sliding Window:
          When swiping left from within the thread, it peeks the media page and lets that slide on top of the thread.
          Then it allows swiping right to leave the media tab and get back to the thread!
      */}
      {effectiveMediaWindowVisible && (
        <div
          data-testid="thread_media_window"
          className="fixed inset-0 z-50 bg-black text-white flex flex-col shadow-2xl transition-transform ease-out duration-150"
          style={{ transform: mediaWindowTranslate }}
        >
          {/* Media Window Header */}
          <div className="w-full pt-4 pb-3 px-4 bg-black border-b border-[#141418] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                data-testid="media_window_back_btn"
                onClick={() => {
                  HapticHelper.gestureSwipe();
                  setIsMediaWindowOpen(false);
                  setMediaPeekProgress(0);
                }}
                className="p-1.5 -ml-1.5 rounded-full hover:bg-white/10"
              >
                <ArrowLeft className="w-5 h-5 text-white" />
              </button>
              <div>
                <div className="flex items-center gap-1.5 font-mono font-bold text-sm">
                  <KnktCmdChatIcon size={18} glow={false} />
                  <span className="text-[#06B6D4]">&gt;_</span>
                  <span>SHARED MEDIA</span>
                </div>
                <p className="text-[11px] text-[#A1A1AA] font-mono">
                  {conversation.recipientName} • {filteredThreadMedia.length} items
                </p>
              </div>
            </div>

            {/* Gesture Hint Button */}
            <button
              onClick={() => {
                HapticHelper.gestureSwipe();
                setIsMediaWindowOpen(false);
                setMediaPeekProgress(0);
              }}
              className="px-3 py-1 rounded-xl bg-[#141418] border border-[#27272A] text-[11px] font-mono text-[#06B6D4] flex items-center gap-1"
            >
              <span>Swipe right to chat →</span>
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 p-3 overflow-x-auto border-b border-[#141418] no-scrollbar">
            {['ALL', 'PHOTOS', 'AUDIO', 'LOCATION', 'DOCS'].map(cat => {
              const isSelected = selectedMediaCategory === cat;
              return (
                <button
                  key={cat}
                  data-testid={`media_filter_${cat.toLowerCase()}`}
                  onClick={() => {
                    setSelectedMediaCategory(cat);
                    HapticHelper.reactionClick();
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-mono font-medium transition-colors shrink-0 ${
                    isSelected
                      ? 'bg-[#06B6D4] text-black font-bold'
                      : 'bg-[#141418] text-[#A1A1AA] border border-[#27272A]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Media Items Grid */}
          <div className="flex-1 overflow-y-auto p-4">
            {filteredThreadMedia.length === 0 ? (
              <div className="py-24 flex flex-col items-center justify-center text-center">
                <Film className="w-12 h-12 text-[#27272A] mb-3" />
                <p className="text-xs font-mono font-bold text-[#71717A]">
                  [ NO MEDIA FOUND ]
                </p>
                <p className="text-xs text-[#A1A1AA] mt-1 font-mono">
                  No attachments in category: {selectedMediaCategory}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-2.5">
                {filteredThreadMedia.map(msg => (
                  <div
                    key={msg.id}
                    data-testid={`media_item_${msg.id}`}
                    onClick={() => setInspectingMessage(msg)}
                    className="h-28 rounded-2xl bg-[#121216] border border-[#27272A] p-2 flex flex-col items-center justify-center text-center cursor-pointer hover:border-[#06B6D4] transition-colors"
                  >
                    <span className="text-2xl mb-1">
                      {msg.attachmentType === 'IMAGE'
                        ? '📷'
                        : msg.attachmentType === 'AUDIO'
                        ? '🎙️'
                        : msg.attachmentType === 'LOCATION'
                        ? '📍'
                        : '📄'}
                    </span>
                    <span className="text-[11px] font-medium text-white truncate w-full px-1">
                      {msg.attachmentTitle || msg.text.slice(0, 16)}
                    </span>
                    <span className="text-[9px] font-mono text-[#06B6D4] mt-0.5">
                      {msg.attachmentType}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Message Long-Press Action Menu with Emoji Reactions */}
      {selectedMessageForAction && (
        <div
          data-testid="message_reaction_menu_modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in"
          onClick={() => setSelectedMessageForAction(null)}
        >
          <div
            className="w-full max-w-xs rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-4 shadow-2xl animate-in zoom-in-95"
            onClick={e => e.stopPropagation()}
          >
            {/* Emoji Reactions Bar */}
            <div className="flex items-center justify-between gap-1 pb-3 mb-3 border-b border-[#1E1E24] overflow-x-auto no-scrollbar">
              {availableEmojis.map(emoji => (
                <button
                  key={emoji}
                  data-testid={`reaction_picker_${emoji}`}
                  onClick={() => {
                    HapticHelper.reactionClick();
                    updateReaction(selectedMessageForAction.id, emoji);
                    setSelectedMessageForAction(null);
                  }}
                  className="w-8 h-8 rounded-full flex items-center justify-center text-lg hover:scale-125 transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="space-y-1 font-mono text-xs">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(selectedMessageForAction.text);
                  HapticHelper.reactionClick();
                  setSelectedMessageForAction(null);
                }}
                className="w-full p-2 rounded-xl hover:bg-[#141418] text-[#A1A1AA] hover:text-white flex items-center gap-2.5 text-left transition-colors"
              >
                <Copy className="w-4 h-4 text-[#06B6D4]" />
                <span>Copy Message Text</span>
              </button>

              {selectedMessageForAction.isEncrypted && (
                <button
                  onClick={() => {
                    setInspectingMessage(selectedMessageForAction);
                    setSelectedMessageForAction(null);
                  }}
                  className="w-full p-2 rounded-xl hover:bg-[#141418] text-[#A1A1AA] hover:text-white flex items-center gap-2.5 text-left transition-colors"
                >
                  <Lock className="w-4 h-4 text-[#10B981]" />
                  <span>Inspect Cipher Packet</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Schedule Send Modal */}
      {showScheduleModal && (
        <ScheduleSendModal
          messageText={inputText.trim() || 'Scheduled message'}
          onDismiss={() => setShowScheduleModal(false)}
          onConfirmSchedule={handleScheduleSend}
        />
      )}

      {/* Crypto Inspector Dialog */}
      {inspectingMessage && (
        <CryptoInspectorDialog
          message={inspectingMessage}
          contactName={conversation.recipientName}
          onDismiss={() => setInspectingMessage(null)}
          onVerifyContactClick={() => {
            setInspectingMessage(null);
            setShowSafetyNumberDialog(true);
          }}
        />
      )}

      {/* Safety Numbers Verification Dialog */}
      {showSafetyNumberDialog && (
        <SafetyNumberDialog
          contactName={conversation.recipientName}
          contactPhone={conversation.recipientPhone}
          isCurrentlyVerified={true}
          onDismiss={() => setShowSafetyNumberDialog(false)}
          onVerificationChanged={verified => {
            verifyContact(conversation.recipientPhone, verified);
          }}
        />
      )}

      {/* Attachment Picker Sheet */}
      {showAttachmentSheet && (
        <AttachmentPickerSheet
          onDismiss={() => setShowAttachmentSheet(false)}
          onAttachPhoto={(uri, title) => {
            sendMessage(
              conversation.id,
              title,
              activeProtocol === 'SMS' ? 'MMS' : activeProtocol,
              isE2EEActive,
              { type: 'IMAGE', title, uri }
            );
          }}
          onAttachAudio={title => {
            sendMessage(conversation.id, title, activeProtocol, isE2EEActive, {
              type: 'AUDIO',
              title,
            });
          }}
          onAttachLocation={title => {
            sendMessage(conversation.id, title, activeProtocol, isE2EEActive, {
              type: 'LOCATION',
              title,
            });
          }}
          onAttachContact={name => {
            sendMessage(conversation.id, name, activeProtocol, isE2EEActive, {
              type: 'CONTACT',
              title: name,
            });
          }}
        />
      )}

      {/* Thread & Bubble Customizer Sheet */}
      {showCustomizerSheet && (
        <ThreadCustomizerSheet
          conversation={conversation}
          onDismiss={() => setShowCustomizerSheet(false)}
          onSaveTheming={(
            userColor,
            peerColor,
            userShape,
            peerShape,
            bgUri,
            groupConfig
          ) => {
            updateCustomTheming(conversation.id, {
              userColor,
              peerColor,
              userShape,
              peerShape,
              bgUri,
              groupConfigJson: groupConfig,
            });
            setShowCustomizerSheet(false);
          }}
        />
      )}
    </div>
  );
};

interface CheckmarkStatusIndicatorProps {
  status: string;
  readReceiptsEnabled: boolean;
  textColor: string;
  testId?: string;
}

const OledCheckmarkStatusIndicator: React.FC<CheckmarkStatusIndicatorProps> = ({
  status,
  readReceiptsEnabled,
  textColor,
  testId,
}) => {
  // If read receipts are turned off by user, show only standard delivery checkmarks without blue read confirmation
  if (!readReceiptsEnabled) {
    if (status === 'SENDING') {
      return (
        <span
          data-testid={testId}
          className="w-1.5 h-1.5 rounded-full inline-block animate-pulse shrink-0"
          style={{ backgroundColor: textColor }}
        />
      );
    }
    return (
      <Check
        data-testid={testId}
        className="w-3 h-3 opacity-60 shrink-0 stroke-[2.5]"
        style={{ color: textColor }}
      />
    );
  }

  switch (status) {
    case 'SENDING':
      return (
        <span
          data-testid={testId}
          className="w-1.5 h-1.5 rounded-full inline-block animate-pulse shrink-0"
          style={{ backgroundColor: textColor }}
        />
      );
    case 'SENT':
      return (
        <Check
          data-testid={testId}
          className="w-3 h-3 opacity-60 shrink-0 stroke-[2.5]"
          style={{ color: textColor }}
        />
      );
    case 'DELIVERED':
      return (
        <CheckCheck
          data-testid={testId}
          className="w-3.5 h-3.5 opacity-70 shrink-0 stroke-[2.5]"
          style={{ color: textColor }}
        />
      );
    case 'READ':
      return (
        <CheckCheck
          data-testid={testId}
          className="w-3.5 h-3.5 text-[#06B6D4] shrink-0 stroke-[2.5] read-receipt-shimmer"
        />
      );
    default:
      return (
        <Check
          data-testid={testId}
          className="w-3 h-3 opacity-50 shrink-0 stroke-[2]"
          style={{ color: textColor }}
        />
      );
  }
};
