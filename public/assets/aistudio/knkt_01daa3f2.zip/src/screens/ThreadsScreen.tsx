import React, { useState } from 'react';
import { useMessaging } from '../context/MessagingContext';
import { PinnedChatsGrid } from '../components/PinnedChatsGrid';
import { SwipeableConversationCard } from '../components/SwipeableConversationCard';
import { ThreadRadialMenu } from '../components/ThreadRadialMenu';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { MessageSquare, Pin, Archive, Trash2, VolumeX, X, CheckSquare } from 'lucide-react';
import { MessageProtocolType, ConversationEntity } from '../types';
import { HapticHelper } from '../utils/haptics';

interface ThreadsScreenProps {
  searchQuery: string;
  onConversationClick: (id: number) => void;
  showNewChatDialog: boolean;
  onDismissNewChatDialog: () => void;
  onSwipeLeftPeek: (id: number, progress: number) => void;
  onNavigateToMedia: () => void;
}

export const ThreadsScreen: React.FC<ThreadsScreenProps> = ({
  searchQuery,
  onConversationClick,
  showNewChatDialog,
  onDismissNewChatDialog,
  onSwipeLeftPeek,
}) => {
  const {
    conversations,
    themePreferences,
    performRightSwipeAction,
    togglePin,
    toggleMute,
    toggleArchive,
    moveToTrash,
    bulkPin,
    bulkArchive,
    bulkDelete,
    bulkMute,
    createOrGetDirectConversation,
  } = useMessaging();

  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [isSelectModeActive, setIsSelectModeActive] = useState(false);
  const isSelectionMode = isSelectModeActive || selectedIds.size > 0;

  // Selected conversation for long-press radial menu
  const [radialMenuConv, setRadialMenuConv] = useState<ConversationEntity | null>(null);

  // Direct threads: not group, not archived, not trash
  const directThreads = conversations.filter(
    c => !c.isGroup && !c.isArchived && !c.isTrash
  );

  const pinnedDirect = directThreads.filter(c => c.isPinned).slice(0, 4);
  const pinnedIds = new Set(pinnedDirect.map(c => c.id));

  // Filter threads by search query
  const filteredThreads = directThreads.filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.recipientName.toLowerCase().includes(q) ||
      c.lastMessage.toLowerCase().includes(q) ||
      c.recipientPhone.includes(q)
    );
  });

  // Deduplicate: pinned threads only appear in the pinned section
  const unpinnedThreads = filteredThreads.filter(c => !pinnedIds.has(c.id));

  const toggleSelect = (id: number) => {
    HapticHelper.reactionClick();
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleLongPressItem = (conv: ConversationEntity) => {
    if (isSelectionMode) {
      toggleSelect(conv.id);
    } else {
      setRadialMenuConv(conv);
    }
  };

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col justify-between pb-28">
      {/* Top Header: Clean and minimal with small KNKT logo at top left and optional Select toggle */}
      <div className="w-full pt-4 pb-3 px-4 bg-black flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <KnktCmdChatIcon size={22} glow={true} />
          <span
            data-testid="knkt_top_left_brand"
            className="font-mono text-base font-extrabold tracking-wider text-white"
          >
            KNKT
          </span>
        </div>

        {/* Select Mode Toggle */}
        <button
          onClick={() => {
            HapticHelper.reactionClick();
            if (isSelectionMode) {
              setSelectedIds(new Set());
              setIsSelectModeActive(false);
            } else {
              setIsSelectModeActive(true);
            }
          }}
          className={`px-3 py-1 rounded-xl text-xs font-mono transition-colors border ${
            isSelectionMode
              ? 'bg-[#06B6D4] text-black border-[#06B6D4] font-bold'
              : 'bg-[#121216] text-[#A1A1AA] hover:text-white border-[#27272A]'
          }`}
        >
          {isSelectionMode ? 'Cancel' : 'Select'}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 px-4 space-y-3">
        {/* Unpinned Threads List */}
        {unpinnedThreads.length === 0 && pinnedDirect.length === 0 ? (
          <div className="py-20 flex flex-col items-center justify-center text-center px-6">
            <MessageSquare className="w-10 h-10 text-[#27272A] mb-2" />
            <p className="text-sm font-medium text-[#A1A1AA]">
              {searchQuery ? 'No matching conversations' : 'No direct conversations yet'}
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {unpinnedThreads.map(conv => (
              <SwipeableConversationCard
                key={conv.id}
                conversation={conv}
                swipeRightAction={themePreferences.swipeRightAction}
                isSelected={selectedIds.has(conv.id)}
                isSelectionMode={isSelectionMode}
                onClick={() => {
                  if (isSelectionMode) toggleSelect(conv.id);
                  else onConversationClick(conv.id);
                }}
                onLongClick={() => handleLongPressItem(conv)}
                onSwipeLeftPeek={progress => onSwipeLeftPeek(conv.id, Number(progress))}
                onSwipeLeftComplete={() => onConversationClick(conv.id)}
                onSwipeRight={() => performRightSwipeAction(conv.id, themePreferences.swipeRightAction)}
              />
            ))}
          </div>
        )}

        {/* Pinned Threads Section */}
        {!searchQuery && pinnedDirect.length > 0 && (
          <div className="mt-4 pt-1">
            <PinnedChatsGrid
              pinnedList={pinnedDirect}
              selectedIds={selectedIds}
              isSelectionMode={isSelectionMode}
              onConversationClick={id => {
                if (isSelectionMode) toggleSelect(id);
                else onConversationClick(id);
              }}
              onConversationLongClick={id => {
                const target = directThreads.find(c => c.id === id);
                if (target) handleLongPressItem(target);
              }}
            />
          </div>
        )}
      </div>

      {/* Context-sensitive Quick Actions Radial Menu on Long Press */}
      {radialMenuConv && (
        <ThreadRadialMenu
          conversation={radialMenuConv}
          onDismiss={() => setRadialMenuConv(null)}
          onTogglePin={() => togglePin(radialMenuConv.id)}
          onToggleMute={() => toggleMute(radialMenuConv.id)}
          onToggleArchive={() => toggleArchive(radialMenuConv.id)}
          onMoveToTrash={() => moveToTrash(radialMenuConv.id)}
          onEnterSelectMode={() => {
            setIsSelectModeActive(true);
            setSelectedIds(new Set([radialMenuConv.id]));
          }}
        />
      )}

      {/* Bulk Operations Floating Toolbar */}
      {isSelectionMode && (
        <div
          data-testid="selection_toolbar"
          className="fixed bottom-20 left-4 right-4 z-40 max-w-md mx-auto rounded-[24px] bg-[#101014] border border-[#27272A] p-3 shadow-2xl flex items-center justify-between animate-in slide-in-from-bottom-4 duration-200"
        >
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-1.5 rounded-full hover:bg-white/10 text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-[#06B6D4] font-mono">
              {selectedIds.size} selected
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              data-testid="selection_pin_btn"
              title="Pin / Unpin"
              onClick={() => {
                bulkPin(Array.from(selectedIds), true);
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#10B981]"
            >
              <Pin className="w-4 h-4" />
            </button>
            <button
              data-testid="selection_mute_btn"
              title="Mute / Unmute"
              onClick={() => {
                bulkMute(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#A855F7]"
            >
              <VolumeX className="w-4 h-4" />
            </button>
            <button
              data-testid="selection_archive_btn"
              title="Archive"
              onClick={() => {
                bulkArchive(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#F59E0B]"
            >
              <Archive className="w-4 h-4" />
            </button>
            <button
              data-testid="selection_trash_btn"
              title="Trash"
              onClick={() => {
                bulkDelete(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#EF4444]"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* New Direct Chat Modal */}
      {showNewChatDialog && (
        <NewDirectChatModal
          onDismiss={onDismissNewChatDialog}
          onStartChat={(name, phone, protocol, isEncrypted) => {
            const id = createOrGetDirectConversation(name, phone, protocol, isEncrypted);
            onDismissNewChatDialog();
            onConversationClick(id);
          }}
        />
      )}
    </div>
  );
};

interface NewDirectChatModalProps {
  onDismiss: () => void;
  onStartChat: (name: string, phone: string, protocol: MessageProtocolType, isEncrypted: boolean) => void;
}

export const NewDirectChatModal: React.FC<NewDirectChatModalProps> = ({
  onDismiss,
  onStartChat,
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [protocol, setProtocol] = useState<MessageProtocolType>('RCS');
  const [isEncrypted, setIsEncrypted] = useState(true);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-md rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <h3 className="font-bold text-white text-base">New Direct Message</h3>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3.5 my-4">
          <div>
            <label className="block text-[11px] font-mono text-[#A1A1AA] uppercase mb-1">
              Contact Name
            </label>
            <input
              data-testid="direct_name_input"
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="e.g. Jordan Lee"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#141418] border border-[#27272A] focus:border-[#06B6D4] text-white text-xs outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-[#A1A1AA] uppercase mb-1">
              Phone Number
            </label>
            <input
              data-testid="direct_phone_input"
              type="text"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+1 (555) 000-0000"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#141418] border border-[#27272A] focus:border-[#06B6D4] text-white text-xs font-mono outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono text-[#06B6D4] font-bold uppercase mb-1.5">
              Transmission Protocol
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['SMS', 'MMS', 'RCS'] as MessageProtocolType[]).map(p => {
                const isSelected = protocol === p;
                return (
                  <button
                    key={p}
                    onClick={() => {
                      setProtocol(p);
                      if (p !== 'RCS') setIsEncrypted(false);
                      else setIsEncrypted(true);
                      HapticHelper.reactionClick();
                    }}
                    className={`py-2 px-3 rounded-xl text-xs font-mono font-bold border transition-all ${
                      isSelected
                        ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4]'
                        : 'bg-[#141418] border-[#27272A] text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    {p}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1E1E24]">
          <button
            onClick={onDismiss}
            className="px-4 py-2 text-xs font-semibold text-[#A1A1AA] hover:text-white"
          >
            Cancel
          </button>
          <button
            data-testid="start_direct_chat_btn"
            disabled={!phone.trim()}
            onClick={() => {
              if (phone.trim()) {
                onStartChat(name.trim() || phone.trim(), phone.trim(), protocol, isEncrypted);
              }
            }}
            className="px-5 py-2.5 rounded-xl bg-[#06B6D4] disabled:opacity-40 text-black font-bold text-xs hover:bg-[#22d3ee] transition-colors"
          >
            Start
          </button>
        </div>
      </div>
    </div>
  );
};
