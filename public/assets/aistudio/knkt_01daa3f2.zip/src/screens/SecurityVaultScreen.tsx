import React, { useState } from 'react';
import { ArrowLeft, Shield, RefreshCw, Lock, CheckCircle, X } from 'lucide-react';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { generateKeyFingerprint } from '../utils/crypto';
import { HapticHelper } from '../utils/haptics';

interface SecurityVaultScreenProps {
  onBackClick: () => void;
}

export const SecurityVaultScreen: React.FC<SecurityVaultScreenProps> = ({
  onBackClick,
}) => {
  const [currentMasterSeed, setCurrentMasterSeed] = useState('KNKT_Salt_v1');
  const [showRegenDialog, setShowRegenDialog] = useState(false);

  const myFingerprint = generateKeyFingerprint(`KNKT_Master_Identity_Key_${currentMasterSeed}`);

  const activeSessions = [
    {
      name: 'Alex Rivera',
      phone: '+1 (555) 019-2834',
      cipher: 'AES-256-GCM',
      ratchetCount: 14,
      status: 'Double-Ratchet Synchronized',
      verified: true,
    },
    {
      name: 'Elena Rostova',
      phone: '+1 (555) 012-3388',
      cipher: 'AES-256-GCM',
      ratchetCount: 6,
      status: 'Double-Ratchet Synchronized',
      verified: true,
    },
    {
      name: 'Sarah Chen',
      phone: '+1 (555) 014-9921',
      cipher: 'AES-256-GCM',
      ratchetCount: 2,
      status: 'E2EE Capable',
      verified: false,
    },
  ];

  const handleRegenerate = () => {
    setCurrentMasterSeed('KNKT_Salt_' + Date.now());
    setShowRegenDialog(false);
    HapticHelper.reactionClick();
  };

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col pb-36">
      {/* Top Header */}
      <div className="w-full pt-4 pb-2 px-4 border-b border-[#141418] bg-black/90 backdrop-blur-md sticky top-0 z-20 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <button onClick={onBackClick} className="p-1 -ml-1 rounded-full hover:bg-white/10">
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          <KnktCmdChatIcon size={22} glow={true} accentColor="#10B981" />
          <div className="flex items-center">
            <span className="font-mono text-sm font-bold text-[#10B981] mr-1">&gt;</span>
            <span className="font-mono text-[14px] font-extrabold tracking-[0.18em] text-white">
              KNKT.sh
            </span>
            <span className="ml-2 px-1.5 py-0.5 rounded bg-[#0A1410] border border-[#10B981]/30 font-mono text-[9px] text-[#10B981] font-semibold">
              vault
            </span>
          </div>
        </div>
        <span className="text-xs font-mono text-[#10B981] font-bold">
          E2EE::LOCKED
        </span>
      </div>

      <div className="flex-1 px-4 space-y-5 mt-2">
        {/* Master Identity Key Card */}
        <div
          data-testid="master_identity_card"
          className="w-full rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-5 shadow-xl"
        >
          <div className="flex items-center gap-3.5 mb-3.5">
            <div className="w-11 h-11 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Device Master Identity Key</h3>
              <p className="text-xs text-[#A1A1AA]">Curve25519 / Ed25519 Handshake</p>
            </div>
          </div>

          <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-1">
            PUBLIC KEY FINGERPRINT
          </span>
          <div className="p-3 rounded-xl bg-black border border-[#1E1E24] font-mono text-xs text-white break-all select-all">
            {myFingerprint}
          </div>

          <div className="flex justify-end mt-3.5">
            <button
              data-testid="regen_keys_btn"
              onClick={() => {
                HapticHelper.reactionClick();
                setShowRegenDialog(true);
              }}
              className="px-3.5 py-1.5 rounded-xl border border-[#27272A] hover:border-[#06B6D4] text-xs font-mono font-medium text-white flex items-center gap-1.5 bg-[#121216] transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Regenerate Keypair</span>
            </button>
          </div>
        </div>

        {/* Active E2EE Sessions */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            ACTIVE E2EE SESSIONS
          </span>
          <div className="space-y-2">
            {activeSessions.map(session => (
              <div
                key={session.name}
                className="w-full rounded-[20px] bg-[#0A0A0C] border border-[#1E1E22] p-3.5 flex items-center gap-3.5"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                    session.verified
                      ? 'bg-[#10B981]/15 text-[#10B981]'
                      : 'bg-[#F59E0B]/15 text-[#F59E0B]'
                  }`}
                >
                  {session.verified ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <Lock className="w-5 h-5" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-white truncate">
                      {session.name}
                    </span>
                    <span className="text-[11px] font-mono font-bold text-[#06B6D4]">
                      • {session.cipher}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#A1A1AA] truncate mt-0.5">
                    {session.status} • Ratchet #{session.ratchetCount}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Cryptographic Architecture Card */}
        <div>
          <span className="px-2 text-[11px] font-mono font-bold tracking-widest text-[#71717A] block mb-2">
            CRYPTOGRAPHIC ARCHITECTURE
          </span>
          <div className="w-full rounded-[22px] bg-[#0A0A0C] border border-[#1E1E22] p-4 space-y-3">
            {[
              {
                title: 'Symmetric Encryption',
                detail: 'AES-256 in Galois/Counter Mode (GCM)',
              },
              {
                title: 'Integrity & Authentication',
                detail: '128-bit GMAC Authentication Tag',
              },
              {
                title: 'Key Derivation',
                detail: 'PBKDF2 with HMAC-SHA256',
              },
              {
                title: 'Forward Secrecy',
                detail: 'Signal Double-Ratchet ephemeral message keys',
              },
              {
                title: 'Telephony Compliance',
                detail: 'Zero-permission Intent routing & local encryption sandbox',
              },
            ].map(row => (
              <div key={row.title} className="text-xs">
                <span className="font-bold text-[#06B6D4] block">{row.title}</span>
                <span className="text-[#A1A1AA]">{row.detail}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Regenerate Keypair Confirm Dialog */}
      {showRegenDialog && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm"
          onClick={() => setShowRegenDialog(false)}
        >
          <div
            className="w-full max-w-sm rounded-[24px] bg-[#0A0A0E] border border-[#27272A] p-5 shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            <h4 className="font-bold text-white text-base">Regenerate Keypair?</h4>
            <p className="text-xs text-[#A1A1AA] my-2 leading-relaxed">
              This will rotate your device&apos;s master cryptographic keypair and renew all
              active Double-Ratchet sessions with your contacts.
            </p>
            <div className="flex items-center justify-end gap-2.5 mt-4">
              <button
                onClick={() => setShowRegenDialog(false)}
                className="px-4 py-2 text-xs font-semibold text-[#A1A1AA] hover:text-white"
              >
                Cancel
              </button>
              <button
                data-testid="confirm_regen_btn"
                onClick={handleRegenerate}
                className="px-4 py-2 rounded-xl bg-[#06B6D4] text-black font-bold text-xs hover:bg-[#22d3ee]"
              >
                Regenerate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
