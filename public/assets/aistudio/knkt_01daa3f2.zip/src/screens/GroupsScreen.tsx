import React, { useState } from 'react';
import { useMessaging } from '../context/MessagingContext';
import { PinnedChatsGrid } from '../components/PinnedChatsGrid';
import { SwipeableConversationCard } from '../components/SwipeableConversationCard';
import { ThreadRadialMenu } from '../components/ThreadRadialMenu';
import { KnktCmdChatIcon } from '../components/KnktCmdChatIcon';
import { Users, Pin, Archive, Trash2, VolumeX, X, CheckSquare } from 'lucide-react';
import { ConversationEntity } from '../types';
import { HapticHelper } from '../utils/haptics';

interface GroupsScreenProps {
  searchQuery: string;
  onConversationClick: (id: number) => void;
  showCreateGroupDialog: boolean;
  onDismissCreateGroupDialog: () => void;
  onSwipeLeftPeek: (id: number, progress: number) => void;
  onNavigateToMedia: () => void;
}

export const GroupsScreen: React.FC<GroupsScreenProps> = ({
  searchQuery,
  onConversationClick,
  showCreateGroupDialog,
  onDismissCreateGroupDialog,
  onSwipeLeftPeek,
}) => {
  const {
    conversations,
    themePreferences,
    performRightSwipeAction,
    togglePin,
    toggleMute,
    toggleArchive,
    moveToTrash,
    bulkPin,
    bulkArchive,
    bulkDelete,
    bulkMute,
    createGroupConversation,
  } = useMessaging();

  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [isSelectModeActive, setIsSelectModeActive] = useState(false);
  const isSelectionMode = isSelectModeActive || selectedIds.size > 0;

  // Selected conversation for long-press radial menu
  const [radialMenuConv, setRadialMenuConv] = useState<ConversationEntity | null>(null);

  // Group threads: isGroup = true, not archived, not trash
  // Pinned groups are strictly isolated to the groups tab!
  const groupThreads = conversations.filter(
    c => c.isGroup && !c.isArchived && !c.isTrash
  );

  const pinnedGroups = groupThreads.filter(c => c.isPinned).slice(0, 4);
  const pinnedGroupIds = new Set(pinnedGroups.map(c => c.id));

  // Filter groups by search query
  const filteredGroups = groupThreads.filter(c => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.recipientName.toLowerCase().includes(q) ||
      (c.groupParticipants && c.groupParticipants.toLowerCase().includes(q)) ||
      c.lastMessage.toLowerCase().includes(q)
    );
  });

  // Deduplicate: pinned groups only appear in the pinned group section
  const unpinnedGroups = filteredGroups.filter(c => !pinnedGroupIds.has(c.id));

  const toggleSelect = (id: number) => {
    HapticHelper.reactionClick();
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleLongPressItem = (conv: ConversationEntity) => {
    if (isSelectionMode) {
      toggleSelect(conv.id);
    } else {
      setRadialMenuConv(conv);
    }
  };

  return (
    <div className="w-full min-h-screen bg-black text-white flex flex-col justify-between pb-28">
      {/* Top Header: Clean and minimal with small KNKT logo and Select toggle */}
      <div className="w-full pt-4 pb-3 px-4 bg-black flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-2">
          <KnktCmdChatIcon size={22} glow={true} accentColor="#8B5CF6" />
          <span
            data-testid="knkt_top_left_groups_brand"
            className="font-mono text-base font-extrabold tracking-wider text-white"
          >
            KNKT
          </span>
          <span className="text-[10px] font-mono text-[#A855F7] font-semibold bg-[#8B5CF6]/15 px-1.5 py-0.5 rounded ml-1">
            groups
          </span>
        </div>

        {/* Select Mode Toggle */}
        <button
          onClick={() => {
            HapticHelper.reactionClick();
            if (isSelectionMode) {
              setSelectedIds(new Set());
              setIsSelectModeActive(false);
            } else {
              setIsSelectModeActive(true);
            }
          }}
          className={`px-3 py-1 rounded-xl text-xs font-mono transition-colors border ${
            isSelectionMode
              ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] font-bold'
              : 'bg-[#121216] text-[#A1A1AA] hover:text-white border-[#27272A]'
          }`}
        >
          {isSelectionMode ? 'Cancel' : 'Select'}
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 px-4 space-y-3">
        {unpinnedGroups.length === 0 && pinnedGroups.length === 0 ? (
          <div className="py-20 flex flex-col items-center justify-center text-center px-6">
            <Users className="w-10 h-10 text-[#27272A] mb-2" />
            <p className="text-sm font-medium text-[#A1A1AA]">
              {searchQuery ? 'No matching group chats' : 'No group chats yet'}
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {unpinnedGroups.map(group => (
              <SwipeableConversationCard
                key={group.id}
                conversation={group}
                swipeRightAction={themePreferences.swipeRightAction}
                isSelected={selectedIds.has(group.id)}
                isSelectionMode={isSelectionMode}
                onClick={() => {
                  if (isSelectionMode) toggleSelect(group.id);
                  else onConversationClick(group.id);
                }}
                onLongClick={() => handleLongPressItem(group)}
                onSwipeLeftPeek={progress => onSwipeLeftPeek(group.id, Number(progress))}
                onSwipeLeftComplete={() => onConversationClick(group.id)}
                onSwipeRight={() => performRightSwipeAction(group.id, themePreferences.swipeRightAction)}
              />
            ))}
          </div>
        )}

        {/* Pinned Group Chats Section */}
        {!searchQuery && pinnedGroups.length > 0 && (
          <div className="mt-4 pt-1">
            <PinnedChatsGrid
              pinnedList={pinnedGroups}
              selectedIds={selectedIds}
              isSelectionMode={isSelectionMode}
              onConversationClick={id => {
                if (isSelectionMode) toggleSelect(id);
                else onConversationClick(id);
              }}
              onConversationLongClick={id => {
                const target = groupThreads.find(c => c.id === id);
                if (target) handleLongPressItem(target);
              }}
            />
          </div>
        )}
      </div>

      {/* Context-sensitive Quick Actions Radial Menu on Long Press */}
      {radialMenuConv && (
        <ThreadRadialMenu
          conversation={radialMenuConv}
          onDismiss={() => setRadialMenuConv(null)}
          onTogglePin={() => togglePin(radialMenuConv.id)}
          onToggleMute={() => toggleMute(radialMenuConv.id)}
          onToggleArchive={() => toggleArchive(radialMenuConv.id)}
          onMoveToTrash={() => moveToTrash(radialMenuConv.id)}
          onEnterSelectMode={() => {
            setIsSelectModeActive(true);
            setSelectedIds(new Set([radialMenuConv.id]));
          }}
        />
      )}

      {/* Bulk Operations Floating Toolbar */}
      {isSelectionMode && (
        <div className="fixed bottom-20 left-4 right-4 z-40 max-w-md mx-auto rounded-[24px] bg-[#101014] border border-[#27272A] p-3 shadow-2xl flex items-center justify-between animate-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-1.5 rounded-full hover:bg-white/10 text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-[#A855F7] font-mono">
              {selectedIds.size} selected
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              title="Pin / Unpin"
              onClick={() => {
                bulkPin(Array.from(selectedIds), true);
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#10B981]"
            >
              <Pin className="w-4 h-4" />
            </button>
            <button
              title="Mute / Unmute"
              onClick={() => {
                bulkMute(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#A855F7]"
            >
              <VolumeX className="w-4 h-4" />
            </button>
            <button
              title="Archive"
              onClick={() => {
                bulkArchive(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#F59E0B]"
            >
              <Archive className="w-4 h-4" />
            </button>
            <button
              title="Trash"
              onClick={() => {
                bulkDelete(Array.from(selectedIds));
                HapticHelper.reactionClick();
                setSelectedIds(new Set());
                setIsSelectModeActive(false);
              }}
              className="p-2 rounded-xl bg-[#141418] hover:bg-[#1E1E24] text-[#EF4444]"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Create Group Dialog */}
      {showCreateGroupDialog && (
        <CreateGroupModal
          onDismiss={onDismissCreateGroupDialog}
          onCreateGroup={(groupName, memberList) => {
            const id = createGroupConversation(groupName, memberList);
            onDismissCreateGroupDialog();
            onConversationClick(id);
          }}
        />
      )}
    </div>
  );
};

interface CreateGroupModalProps {
  onDismiss: () => void;
  onCreateGroup: (name: string, members: string[]) => void;
}

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({
  onDismiss,
  onCreateGroup,
}) => {
  const [groupName, setGroupName] = useState('');
  const [memberInput, setMemberInput] = useState('');
  const [members, setMembers] = useState<string[]>(['Alex Rivera', 'Taylor Morgan']);

  const addMember = () => {
    if (memberInput.trim() && !members.includes(memberInput.trim())) {
      setMembers([...members, memberInput.trim()]);
      setMemberInput('');
      HapticHelper.reactionClick();
    }
  };

  const removeMember = (m: string) => {
    setMembers(members.filter(x => x !== m));
    HapticHelper.reactionClick();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-md rounded-[26px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <h3 className="font-bold text-white text-base">New Group Chat (3+)</h3>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3.5 my-4">
          <div>
            <label className="block text-[11px] font-mono text-[#A1A1AA] uppercase mb-1">
              Group Name
            </label>
            <input
              data-testid="group_name_input"
              type="text"
              value={groupName}
              onChange={e => setGroupName(e.target.value)}
              placeholder="e.g. Design Systems"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#141418] border border-[#27272A] focus:border-[#8B5CF6] text-white text-xs outline-none"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-mono text-[#A1A1AA] uppercase">
                Participants ({members.length + 1} including you)
              </span>
            </div>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {members.map(m => (
                <div
                  key={m}
                  className="flex items-center justify-between px-3 py-2 rounded-xl bg-[#141418] border border-[#27272A]"
                >
                  <span className="text-xs text-white">{m}</span>
                  <button
                    onClick={() => removeMember(m)}
                    className="text-[11px] font-medium text-[#EF4444] hover:underline"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              data-testid="group_member_input"
              type="text"
              value={memberInput}
              onChange={e => setMemberInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addMember();
                }
              }}
              placeholder="Add participant name"
              className="flex-1 px-3.5 py-2 rounded-xl bg-[#141418] border border-[#27272A] focus:border-[#8B5CF6] text-white text-xs outline-none"
            />
            <button
              onClick={addMember}
              disabled={!memberInput.trim()}
              className="px-3.5 py-2 rounded-xl bg-[#1E1E24] hover:bg-[#27272A] text-white text-xs font-semibold disabled:opacity-40"
            >
              Add
            </button>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1E1E24]">
          <button
            onClick={onDismiss}
            className="px-4 py-2 text-xs font-semibold text-[#A1A1AA] hover:text-white"
          >
            Cancel
          </button>
          <button
            data-testid="confirm_create_group_btn"
            disabled={!groupName.trim() || members.length < 2}
            onClick={() => {
              if (groupName.trim() && members.length >= 2) {
                onCreateGroup(groupName.trim(), members);
              }
            }}
            className="px-5 py-2.5 rounded-xl bg-[#8B5CF6] disabled:opacity-40 text-white font-bold text-xs hover:bg-[#7c3aed] transition-colors"
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
};
