import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  ConversationEntity,
  MessageEntity,
  ContactEntity,
  ThemePreferences,
  MessageProtocolType,
  SwipeRightAction,
  BubbleShapeType,
  AttachmentType,
} from '../types';
import { encryptMessage, generateKeyFingerprint } from '../utils/crypto';
import { HapticHelper } from '../utils/haptics';

interface MessagingContextType {
  conversations: ConversationEntity[];
  messages: MessageEntity[];
  contacts: ContactEntity[];
  themePreferences: ThemePreferences;
  typingStatus: Record<number, string>; // conversationId -> senderName
  updateThemePreferences: (updater: (prev: ThemePreferences) => ThemePreferences) => void;
  markConversationRead: (conversationId: number) => void;
  toggleReadStatus: (conversationId: number) => void;
  togglePin: (conversationId: number) => boolean;
  toggleMute: (conversationId: number) => void;
  toggleArchive: (conversationId: number) => void;
  moveToTrash: (conversationId: number) => void;
  restoreFromTrash: (conversationId: number) => void;
  emptyTrash: () => void;
  bulkPin: (ids: number[], pin: boolean) => void;
  bulkArchive: (ids: number[]) => void;
  bulkDelete: (ids: number[]) => void;
  bulkMute: (ids: number[]) => void;
  performRightSwipeAction: (conversationId: number, action: SwipeRightAction) => string;
  updateCustomTheming: (
    conversationId: number,
    theming: {
      userColor?: string;
      peerColor?: string;
      userShape?: BubbleShapeType;
      peerShape?: BubbleShapeType;
      bgUri?: string;
      groupConfigJson?: string;
    }
  ) => void;
  createGroupConversation: (title: string, participants: string[]) => number;
  createOrGetDirectConversation: (
    name: string,
    phone: string,
    protocol?: MessageProtocolType,
    isEncrypted?: boolean
  ) => number;
  sendMessage: (
    conversationId: number,
    text: string,
    protocol: MessageProtocolType,
    isEncrypted: boolean,
    attachment?: {
      type: AttachmentType;
      title: string;
      uri?: string;
    },
    replyToText?: string,
    scheduledFor?: number
  ) => void;
  updateReaction: (messageId: number, reaction: string | null) => void;
  verifyContact: (phone: string, isVerified: boolean) => void;
  updateProtocol: (conversationId: number, protocol: MessageProtocolType) => void;
  updateE2EE: (conversationId: number, isE2EE: boolean) => void;
}

const MessagingContext = createContext<MessagingContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CONVERSATIONS: 'knkt_conversations_v2',
  MESSAGES: 'knkt_messages_v2',
  CONTACTS: 'knkt_contacts_v2',
  THEME_PREFS: 'knkt_theme_prefs_v2',
};

const alexPhone = '+1 (555) 019-2834';
const sarahPhone = '+1 (555) 014-9921';
const davidPhone = '+1 (555) 018-7744';
const elenaPhone = '+1 (555) 012-3388';
const marcusPhone = '+1 (555) 017-6655';

function getInitialContacts(): ContactEntity[] {
  return [
    {
      id: 1,
      name: 'Alex Rivera',
      phone: alexPhone,
      avatarColorHex: '#06B6D4', // Neon Cyan
      status: 'Designing OLED interfaces',
      isE2EEVerified: true,
      rcsCapable: true,
      keyFingerprint: generateKeyFingerprint(alexPhone),
    },
    {
      id: 2,
      name: 'Sarah Chen',
      phone: sarahPhone,
      avatarColorHex: '#10B981', // Emerald Green
      status: 'Exploring Seoul 🌸',
      isE2EEVerified: true,
      rcsCapable: true,
      keyFingerprint: generateKeyFingerprint(sarahPhone),
    },
    {
      id: 3,
      name: 'David Kim',
      phone: davidPhone,
      avatarColorHex: '#3B82F6', // Royal Blue
      status: 'Running late for coffee ☕',
      isE2EEVerified: false,
      rcsCapable: true,
      keyFingerprint: generateKeyFingerprint(davidPhone),
    },
    {
      id: 4,
      name: 'Elena Rostova',
      phone: elenaPhone,
      avatarColorHex: '#A855F7', // Neon Purple
      status: 'Security Key: Verified 🛡️',
      isE2EEVerified: true,
      rcsCapable: true,
      keyFingerprint: generateKeyFingerprint(elenaPhone),
    },
    {
      id: 5,
      name: 'Marcus Vance',
      phone: marcusPhone,
      avatarColorHex: '#F97316', // Vibrant Orange
      status: 'Testing SMS/MMS fallbacks',
      isE2EEVerified: false,
      rcsCapable: false,
      keyFingerprint: '',
    },
  ];
}

function getInitialConversations(): ConversationEntity[] {
  const now = Date.now();
  const min = 60 * 1000;

  return [
    {
      id: 1,
      recipientName: 'Alex Rivera',
      recipientPhone: alexPhone,
      avatarColorHex: '#06B6D4',
      activeProtocol: 'RCS',
      isE2EE: true,
      isGroup: false,
      lastMessage: 'Pure black OLED theme is flawless! ⚡',
      lastTimestamp: now - 3 * min,
      unreadCount: 2,
      isPinned: true, // Pin 1
      isArchived: false,
      isTrash: false,
      customUserBubbleColor: '#06B6D4',
      customPeerBubbleColor: '#1E293B',
      customUserBubbleShape: 'ROUNDED',
      customPeerBubbleShape: 'ROUNDED',
    },
    {
      id: 2,
      recipientName: 'Sarah Chen',
      recipientPhone: sarahPhone,
      avatarColorHex: '#10B981',
      activeProtocol: 'RCS',
      isE2EE: true,
      isGroup: false,
      lastMessage: 'Sent a photo from Namsan Tower 🗼',
      lastTimestamp: now - 22 * min,
      unreadCount: 0,
      isPinned: true, // Pin 2 (demonstrating side-by-side card grid!)
      isArchived: false,
      isTrash: false,
      customUserBubbleColor: '#10B981',
      customPeerBubbleColor: '#064E3B',
      customUserBubbleShape: 'PILL',
      customPeerBubbleShape: 'PILL',
    },
    {
      id: 3,
      recipientName: 'David Kim',
      recipientPhone: davidPhone,
      avatarColorHex: '#3B82F6',
      activeProtocol: 'SMS',
      isE2EE: false,
      isGroup: false,
      lastMessage: 'Meeting you downstairs in 5 mins',
      lastTimestamp: now - 45 * min,
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
    },
    {
      id: 4,
      recipientName: 'Elena Rostova',
      recipientPhone: elenaPhone,
      avatarColorHex: '#A855F7',
      activeProtocol: 'RCS',
      isE2EE: true,
      isGroup: false,
      lastMessage: 'Confirmed: AES-256-GCM cipher exchange valid 🔒',
      lastTimestamp: now - 2 * 60 * min,
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
    },
    {
      id: 5,
      recipientName: 'Marcus Vance',
      recipientPhone: marcusPhone,
      avatarColorHex: '#F97316',
      activeProtocol: 'SMS',
      isE2EE: false,
      isGroup: false,
      lastMessage: 'Got the MMS dispatch notification 📱',
      lastTimestamp: now - 6 * 60 * min,
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
    },
    {
      id: 6,
      recipientName: 'KNKT Core Devs',
      recipientPhone: 'group_knkt_devs',
      avatarColorHex: '#8B5CF6',
      activeProtocol: 'RCS',
      isE2EE: true,
      isGroup: true,
      groupParticipants: 'Alex Rivera, Sarah Chen, Elena Rostova, David Kim',
      lastMessage: 'Elena: All 4 pinned cards render with zero latency!',
      lastTimestamp: now - 8 * min,
      unreadCount: 3,
      isPinned: false,
      isArchived: false,
      isTrash: false,
      groupBubbleConfigJson:
        'Alex Rivera|#06B6D4|ROUNDED;Sarah Chen|#10B981|PILL;Elena Rostova|#A855F7|RECTANGULAR;David Kim|#3B82F6|ROUNDED',
    },
    {
      id: 7,
      recipientName: 'Seoul Travel Crew',
      recipientPhone: 'group_seoul_crew',
      avatarColorHex: '#EC4899',
      activeProtocol: 'RCS',
      isE2EE: false,
      isGroup: true,
      groupParticipants: 'Sarah Chen, Elena Rostova, Marcus Vance',
      lastMessage: 'Sarah: Check out this dinner spot recommendation!',
      lastTimestamp: now - 3 * 60 * min,
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
      groupBubbleConfigJson:
        'Sarah Chen|#EC4899|PILL;Elena Rostova|#A855F7|ROUNDED;Marcus Vance|#F97316|RECTANGULAR',
    },
  ];
}

function getInitialMessages(): MessageEntity[] {
  const now = Date.now();
  const min = 60 * 1000;
  const enc1 = encryptMessage('Pure black OLED theme is flawless! ⚡', alexPhone);

  return [
    {
      id: 1,
      conversationId: 1,
      sender: 'Alex Rivera',
      isFromUser: false,
      text: 'Pure black OLED theme is flawless! ⚡',
      timestamp: now - 3 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: true,
      cipherTextBase64: enc1.cipherTextBase64,
      ivHex: enc1.ivHex,
      tagHex: enc1.tagHex,
      reaction: '❤️',
    },
    {
      id: 2,
      conversationId: 2,
      sender: 'Sarah Chen',
      isFromUser: false,
      text: 'Sent a photo from Namsan Tower 🗼',
      timestamp: now - 22 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: true,
      attachmentType: 'IMAGE',
      attachmentTitle: 'namsan_seoul_tower.jpg',
      attachmentUri: 'https://images.unsplash.com/photo-1546874177-9e664107314e?w=800',
      reaction: '🔥',
    },
    {
      id: 3,
      conversationId: 2,
      sender: 'ME',
      isFromUser: true,
      text: 'Voice Memo (0:18)',
      timestamp: now - 20 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: true,
      attachmentType: 'AUDIO',
      attachmentTitle: 'Voice Memo (0:18)',
    },
    {
      id: 4,
      conversationId: 7,
      sender: 'Sarah Chen',
      isFromUser: false,
      text: 'Gwangjang Market Food Alley',
      timestamp: now - 3 * 60 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: false,
      attachmentType: 'LOCATION',
      attachmentTitle: '37.5700° N, 126.9997° E',
    },
    {
      id: 5,
      conversationId: 6,
      sender: 'Elena Rostova',
      isFromUser: false,
      text: 'KNKT_Architecture_Spec_v2.pdf',
      timestamp: now - 12 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: true,
      attachmentType: 'FILE',
      attachmentTitle: 'KNKT_Architecture_Spec_v2.pdf',
    },
    {
      id: 6,
      conversationId: 6,
      sender: 'Elena Rostova',
      isFromUser: false,
      text: 'All 4 pinned cards render with zero latency!',
      timestamp: now - 8 * min,
      status: 'READ',
      protocol: 'RCS',
      isEncrypted: true,
    },
  ];
}

export const MessagingProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [conversations, setConversations] = useState<ConversationEntity[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return getInitialConversations();
  });

  const [messages, setMessages] = useState<MessageEntity[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      if (saved) return JSON.parse(saved);
    } catch {}
    return getInitialMessages();
  });

  const [contacts, setContacts] = useState<ContactEntity[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONTACTS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return getInitialContacts();
  });

  const [themePreferences, setThemePreferences] = useState<ThemePreferences>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME_PREFS);
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      isOledBlack: true,
      customAccentHex: '#06B6D4',
      swipeRightAction: 'MARK_READ_UNREAD',
      defaultBubbleShape: 'ROUNDED',
      squircleRadiusDp: 20,
      fontSizeScale: 1.0,
      hapticFeedback: true,
      quickReplyEnabled: true,
      readReceiptsEnabled: true,
      bubbleRadius: 20,
      bubbleTailStyle: 'CLASSIC',
    };
  });

  const [typingStatus, setTypingStatus] = useState<Record<number, string>>({});

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.THEME_PREFS, JSON.stringify(themePreferences));
  }, [themePreferences]);

  const updateThemePreferences = (updater: (prev: ThemePreferences) => ThemePreferences) => {
    setThemePreferences(prev => updater(prev));
  };

  const markConversationRead = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, unreadCount: 0 } : c))
    );
  };

  const toggleReadStatus = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, unreadCount: c.unreadCount === 0 ? 1 : 0 } : c))
    );
  };

  const toggleMute = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, isMuted: !c.isMuted } : c))
    );
  };

  const togglePin = (conversationId: number): boolean => {
    const conv = conversations.find(c => c.id === conversationId);
    if (!conv) return false;

    if (conv.isPinned) {
      setConversations(prev =>
        prev.map(c => (c.id === conversationId ? { ...c, isPinned: false } : c))
      );
      return true;
    } else {
      const currentPinned = conversations.filter(
        c => c.isPinned && !c.isArchived && !c.isTrash && Boolean(c.isGroup) === Boolean(conv.isGroup)
      );
      if (currentPinned.length >= 4) {
        return false;
      }
      setConversations(prev =>
        prev.map(c => (c.id === conversationId ? { ...c, isPinned: true } : c))
      );
      return true;
    }
  };

  const bulkPin = (ids: number[], pin: boolean) => {
    const idSet = new Set(ids);
    setConversations(prev =>
      prev.map(c => {
        if (!idSet.has(c.id)) return c;
        return { ...c, isPinned: pin };
      })
    );
  };

  const bulkArchive = (ids: number[]) => {
    const idSet = new Set(ids);
    setConversations(prev =>
      prev.map(c => {
        if (!idSet.has(c.id)) return c;
        return { ...c, isArchived: true, isTrash: false, isPinned: false };
      })
    );
  };

  const bulkDelete = (ids: number[]) => {
    const idSet = new Set(ids);
    setConversations(prev =>
      prev.map(c => {
        if (!idSet.has(c.id)) return c;
        return { ...c, isTrash: true, isPinned: false };
      })
    );
  };

  const bulkMute = (ids: number[]) => {
    const idSet = new Set(ids);
    setConversations(prev =>
      prev.map(c => {
        if (!idSet.has(c.id)) return c;
        return { ...c, isMuted: !c.isMuted };
      })
    );
  };

  const toggleArchive = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c =>
        c.id === conversationId
          ? { ...c, isArchived: !c.isArchived, isTrash: false, isPinned: false }
          : c
      )
    );
  };

  const moveToTrash = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c =>
        c.id === conversationId
          ? { ...c, isTrash: true, isPinned: false }
          : c
      )
    );
  };

  const restoreFromTrash = (conversationId: number) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, isTrash: false } : c))
    );
  };

  const emptyTrash = () => {
    setConversations(prev => prev.filter(c => !c.isTrash));
  };

  const performRightSwipeAction = (conversationId: number, action: SwipeRightAction): string => {
    switch (action) {
      case 'MARK_READ_UNREAD':
        toggleReadStatus(conversationId);
        return 'Toggled read status';
      case 'ARCHIVE':
        toggleArchive(conversationId);
        return 'Conversation archived';
      case 'TRASH':
        moveToTrash(conversationId);
        return 'Moved to Trash';
      case 'PIN': {
        const success = togglePin(conversationId);
        return success ? 'Pin status updated' : 'Maximum 4 pinned chats reached';
      }
    }
  };

  const updateCustomTheming = (
    conversationId: number,
    theming: {
      userColor?: string;
      peerColor?: string;
      userShape?: BubbleShapeType;
      peerShape?: BubbleShapeType;
      bgUri?: string;
      groupConfigJson?: string;
    }
  ) => {
    setConversations(prev =>
      prev.map(c => {
        if (c.id !== conversationId) return c;
        return {
          ...c,
          customUserBubbleColor: theming.userColor !== undefined ? theming.userColor : c.customUserBubbleColor,
          customPeerBubbleColor: theming.peerColor !== undefined ? theming.peerColor : c.customPeerBubbleColor,
          customUserBubbleShape: theming.userShape !== undefined ? theming.userShape : c.customUserBubbleShape,
          customPeerBubbleShape: theming.peerShape !== undefined ? theming.peerShape : c.customPeerBubbleShape,
          customBackgroundUri: theming.bgUri !== undefined ? theming.bgUri : c.customBackgroundUri,
          groupBubbleConfigJson: theming.groupConfigJson !== undefined ? theming.groupConfigJson : c.groupBubbleConfigJson,
        };
      })
    );
  };

  const createGroupConversation = (title: string, participants: string[]): number => {
    const newId = Date.now();
    const participantsStr = participants.join(', ');
    const colors = ['#06B6D4', '#10B981', '#3B82F6', '#A855F7', '#F97316', '#EC4899'];
    const shapes: BubbleShapeType[] = ['ROUNDED', 'RECTANGULAR', 'PILL'];

    const groupConfig = participants
      .map((p, idx) => `${p}|${colors[idx % colors.length]}|${shapes[idx % shapes.length]}`)
      .join(';');

    const newGroup: ConversationEntity = {
      id: newId,
      recipientName: title.trim() || 'Group Chat',
      recipientPhone: `group_${newId}`,
      avatarColorHex: '#8B5CF6',
      activeProtocol: 'RCS',
      isE2EE: true,
      isGroup: true,
      groupParticipants: participantsStr,
      lastMessage: `Created group with ${participants.length} members`,
      lastTimestamp: Date.now(),
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
      groupBubbleConfigJson: groupConfig,
    };

    setConversations(prev => [newGroup, ...prev]);
    return newId;
  };

  const createOrGetDirectConversation = (
    name: string,
    phone: string,
    protocol: MessageProtocolType = 'RCS',
    isEncrypted: boolean = true
  ): number => {
    const existing = conversations.find(c => c.recipientPhone === phone);
    if (existing) {
      if (existing.isTrash) {
        restoreFromTrash(existing.id);
      }
      return existing.id;
    }

    const newId = Date.now();
    const colors = ['#06B6D4', '#10B981', '#3B82F6', '#A855F7', '#F97316'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const newConv: ConversationEntity = {
      id: newId,
      recipientName: name.trim() || phone,
      recipientPhone: phone,
      avatarColorHex: randomColor,
      activeProtocol: protocol,
      isE2EE: isEncrypted,
      isGroup: false,
      lastMessage: 'Started conversation',
      lastTimestamp: Date.now(),
      unreadCount: 0,
      isPinned: false,
      isArchived: false,
      isTrash: false,
    };

    setConversations(prev => [newConv, ...prev]);

    // Also register contact if missing
    if (!contacts.some(c => c.phone === phone)) {
      setContacts(prev => [
        ...prev,
        {
          id: Date.now(),
          name: name.trim() || phone,
          phone,
          avatarColorHex: randomColor,
          status: 'Available on KNKT',
          isE2EEVerified: false,
          rcsCapable: protocol === 'RCS',
          keyFingerprint: generateKeyFingerprint(phone),
        },
      ]);
    }

    return newId;
  };

  const updateReaction = (messageId: number, reaction: string | null) => {
    setMessages(prev =>
      prev.map(m => (m.id === messageId ? { ...m, reaction: reaction || undefined } : m))
    );
  };

  const verifyContact = (phone: string, isVerified: boolean) => {
    setContacts(prev =>
      prev.map(c => (c.phone === phone ? { ...c, isE2EEVerified: isVerified } : c))
    );
  };

  const updateProtocol = (conversationId: number, protocol: MessageProtocolType) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, activeProtocol: protocol } : c))
    );
  };

  const updateE2EE = (conversationId: number, isE2EE: boolean) => {
    setConversations(prev =>
      prev.map(c => (c.id === conversationId ? { ...c, isE2EE } : c))
    );
  };

  const generateReply = (
    conv: ConversationEntity,
    userQuery: string,
    isEnc: boolean
  ): string => {
    const q = userQuery.toLowerCase();
    if (q.includes('hello') || q.includes('hey') || q.includes('hi')) {
      return conv.isGroup
        ? 'Hey everyone! Checking in from KNKT.'
        : 'Hey! The pure OLED black look on KNKT is incredible.';
    }
    if (q.includes('pin') || q.includes('card') || q.includes('grid')) {
      return 'The dynamic 1-4 pinned cards grid reorganizes super cleanly on high refresh OLED.';
    }
    if (q.includes('color') || q.includes('bubble') || q.includes('theme')) {
      return 'Love that each member in our group can have custom bubble colors and shapes!';
    }
    if (q.includes('photo') || q.includes('media') || q.includes('picture')) {
      return 'Awesome shot! You can find it indexed under the Media tab anytime.';
    }
    if (q.includes('encrypt') || q.includes('security') || q.includes('lock')) {
      return isEnc
        ? 'Verified! End-to-end encrypted with AES-256-GCM 🔒'
        : 'Transmitting unencrypted standard packet.';
    }
    return `Got your message via KNKT ${isEnc ? 'E2EE' : 'carrier'} connection.`;
  };

  const sendMessage = (
    conversationId: number,
    text: string,
    protocol: MessageProtocolType,
    isEncrypted: boolean,
    attachment?: {
      type: AttachmentType;
      title: string;
      uri?: string;
    },
    replyToText?: string,
    scheduledFor?: number
  ) => {
    const conv = conversations.find(c => c.id === conversationId);
    if (!conv) return;

    let cipherTextBase64: string | undefined;
    let ivHex: string | undefined;
    let tagHex: string | undefined;

    if (isEncrypted) {
      const enc = encryptMessage(text, conv.recipientPhone);
      cipherTextBase64 = enc.cipherTextBase64;
      ivHex = enc.ivHex;
      tagHex = enc.tagHex;
    }

    const messageId = Date.now();
    const isScheduled = !!scheduledFor && scheduledFor > Date.now();

    const sentMsg: MessageEntity = {
      id: messageId,
      conversationId,
      sender: 'ME',
      isFromUser: true,
      text,
      timestamp: Date.now(),
      status: 'SENDING',
      protocol,
      isEncrypted,
      cipherTextBase64,
      ivHex,
      tagHex,
      attachmentType: attachment?.type,
      attachmentTitle: attachment?.title,
      attachmentUri: attachment?.uri,
      replyToText,
      isScheduled,
      scheduledFor,
    };

    setMessages(prev => [...prev, sentMsg]);
    HapticHelper.messageSend();

    const summaryText = isScheduled
      ? `⏰ Scheduled: ${text}`
      : attachment
      ? attachment.type === 'IMAGE'
        ? '📷 Photo attached'
        : attachment.type === 'AUDIO'
        ? '🎙️ Voice memo'
        : attachment.type === 'LOCATION'
        ? '📍 Location shared'
        : '📄 Document'
      : text;

    setConversations(prev =>
      prev.map(c =>
        c.id === conversationId
          ? {
              ...c,
              lastMessage: summaryText,
              lastTimestamp: sentMsg.timestamp,
              activeProtocol: protocol,
              isE2EE: isEncrypted,
            }
          : c
      )
    );

    // Simulate network progression: SENDING -> SENT -> DELIVERED
    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => (m.id === messageId ? { ...m, status: 'SENT' } : m))
      );
    }, 350);

    setTimeout(() => {
      setMessages(prev =>
        prev.map(m => (m.id === messageId ? { ...m, status: 'DELIVERED' } : m))
      );
    }, 750);

    // Simulate incoming reply if not alert or test
    if (!conv.recipientName.toLowerCase().includes('alert')) {
      const responderName = conv.isGroup
        ? conv.groupParticipants?.split(',').map(s => s.trim())[0] || 'Alex Rivera'
        : conv.recipientName;

      setTimeout(() => {
        setTypingStatus(prev => ({ ...prev, [conversationId]: responderName }));

        setTimeout(() => {
          setTypingStatus(prev => {
            const next = { ...prev };
            delete next[conversationId];
            return next;
          });

          const replyText = generateReply(conv, text, isEncrypted);
          let replyCipher: string | undefined;
          let replyIv: string | undefined;
          let replyTag: string | undefined;

          if (isEncrypted) {
            const enc = encryptMessage(replyText, conv.recipientPhone);
            replyCipher = enc.cipherTextBase64;
            replyIv = enc.ivHex;
            replyTag = enc.tagHex;
          }

          const replyMsg: MessageEntity = {
            id: Date.now() + 1,
            conversationId,
            sender: responderName,
            isFromUser: false,
            text: replyText,
            timestamp: Date.now(),
            status: 'READ',
            protocol,
            isEncrypted,
            cipherTextBase64: replyCipher,
            ivHex: replyIv,
            tagHex: replyTag,
          };

          setMessages(prev => [...prev, replyMsg]);
          setConversations(prev =>
            prev.map(c =>
              c.id === conversationId
                ? {
                    ...c,
                    lastMessage: conv.isGroup ? `${responderName}: ${replyText}` : replyText,
                    lastTimestamp: replyMsg.timestamp,
                    activeProtocol: protocol,
                    isE2EE: isEncrypted,
                  }
                : c
            )
          );
          HapticHelper.incomingNotification();
        }, 1600);
      }, 1000);
    }
  };

  return (
    <MessagingContext.Provider
      value={{
        conversations,
        messages,
        contacts,
        themePreferences,
        typingStatus,
        updateThemePreferences,
        markConversationRead,
        toggleReadStatus,
        togglePin,
        toggleMute,
        toggleArchive,
        moveToTrash,
        restoreFromTrash,
        emptyTrash,
        bulkPin,
        bulkArchive,
        bulkDelete,
        bulkMute,
        performRightSwipeAction,
        updateCustomTheming,
        createGroupConversation,
        createOrGetDirectConversation,
        sendMessage,
        updateReaction,
        verifyContact,
        updateProtocol,
        updateE2EE,
      }}
    >
      {children}
    </MessagingContext.Provider>
  );
};

export const useMessaging = (): MessagingContextType => {
  const context = useContext(MessagingContext);
  if (!context) {
    throw new Error('useMessaging must be used within a MessagingProvider');
  }
  return context;
};
