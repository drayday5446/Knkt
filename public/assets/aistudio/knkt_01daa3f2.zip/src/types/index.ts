export type MessageProtocolType = 'SMS' | 'MMS' | 'RCS';

export interface MessageProtocolInfo {
  name: MessageProtocolType;
  label: string;
  badgeColor: string;
  description: string;
  maxChars: number;
  supportsMedia: boolean;
  supportsEncryption: boolean;
}

export const PROTOCOL_CONFIGS: Record<MessageProtocolType, MessageProtocolInfo> = {
  SMS: {
    name: 'SMS',
    label: 'SMS',
    badgeColor: '#64748B', // Slate Gray
    description: 'Carrier Cellular Text',
    maxChars: 160,
    supportsMedia: false,
    supportsEncryption: false,
  },
  MMS: {
    name: 'MMS',
    label: 'MMS',
    badgeColor: '#0284C7', // Sky Blue
    description: 'Multimedia Messaging (Media, Audio)',
    maxChars: 1000,
    supportsMedia: true,
    supportsEncryption: false,
  },
  RCS: {
    name: 'RCS',
    label: 'RCS',
    badgeColor: '#06B6D4', // Neon Cyan
    description: 'Rich Communication Services (E2EE)',
    maxChars: 8000,
    supportsMedia: true,
    supportsEncryption: true,
  },
};

export type DeliveryStatus = 'SENDING' | 'SENT' | 'DELIVERED' | 'READ' | 'FAILED';

export type SwipeRightAction = 'MARK_READ_UNREAD' | 'ARCHIVE' | 'TRASH' | 'PIN';

export interface SwipeRightActionInfo {
  type: SwipeRightAction;
  displayName: string;
  iconDescription: string;
}

export const SWIPE_RIGHT_ACTIONS: SwipeRightActionInfo[] = [
  { type: 'MARK_READ_UNREAD', displayName: 'Mark Read / Unread', iconDescription: 'Toggle read status' },
  { type: 'ARCHIVE', displayName: 'Archive Thread', iconDescription: 'Move to archive' },
  { type: 'TRASH', displayName: 'Move to Trash', iconDescription: 'Delete conversation' },
  { type: 'PIN', displayName: 'Pin / Unpin', iconDescription: 'Toggle pin status' },
];

export type BubbleShapeType = 'ROUNDED' | 'RECTANGULAR' | 'PILL' | 'CHAT_TAIL';

export interface BubbleShapeInfo {
  type: BubbleShapeType;
  displayName: string;
  description: string;
}

export const BUBBLE_SHAPES: BubbleShapeInfo[] = [
  { type: 'ROUNDED', displayName: 'Rounded Squircle', description: 'Classic Samsung One UI squircle' },
  { type: 'RECTANGULAR', displayName: 'Sharp Rectangular', description: 'Sharp modern cyberpunk edges' },
  { type: 'PILL', displayName: 'Smooth Pill', description: 'Ultra-rounded continuous pill' },
  { type: 'CHAT_TAIL', displayName: 'Message Tail', description: 'Dynamic directional message tail' },
];

export interface ConversationEntity {
  id: number;
  recipientName: string;
  recipientPhone: string;
  avatarColorHex: string;
  activeProtocol: MessageProtocolType;
  isE2EE: boolean;
  isGroup: boolean;
  groupParticipants?: string; // e.g. "Alex Rivera, Sarah Chen, Elena Rostova"
  lastMessage: string;
  lastTimestamp: number;
  unreadCount: number;
  isPinned: boolean;
  isArchived: boolean;
  isTrash: boolean;
  isMuted?: boolean;
  customUserBubbleColor?: string;
  customPeerBubbleColor?: string;
  customUserBubbleShape?: BubbleShapeType;
  customPeerBubbleShape?: BubbleShapeType;
  customBackgroundUri?: string;
  groupBubbleConfigJson?: string; // "Alex Rivera|#06B6D4|ROUNDED;Sarah Chen|#10B981|PILL;..."
}

export type AttachmentType = 'IMAGE' | 'AUDIO' | 'LOCATION' | 'FILE' | 'CONTACT';

export type BubbleTailStyle = 'NONE' | 'CLASSIC' | 'SUBTLE' | 'CORNER_CUT';

export interface MessageEntity {
  id: number;
  conversationId: number;
  sender: string;
  isFromUser: boolean;
  text: string;
  timestamp: number;
  status: DeliveryStatus;
  protocol: MessageProtocolType;
  isEncrypted: boolean;
  cipherTextBase64?: string;
  ivHex?: string;
  tagHex?: string;
  attachmentUri?: string;
  attachmentType?: AttachmentType;
  attachmentTitle?: string;
  reaction?: string;
  replyToText?: string;
  isScheduled?: boolean;
  scheduledFor?: number;
}

export interface ContactEntity {
  id: number;
  name: string;
  phone: string;
  avatarColorHex: string;
  status: string;
  isE2EEVerified: boolean;
  rcsCapable: boolean;
  keyFingerprint: string;
}

export interface ThemePreferences {
  isOledBlack: boolean;
  customAccentHex: string;
  swipeRightAction: SwipeRightAction;
  defaultBubbleShape: BubbleShapeType;
  squircleRadiusDp: number;
  fontSizeScale: number;
  hapticFeedback: boolean;
  quickReplyEnabled: boolean;
  readReceiptsEnabled: boolean;
  bubbleRadius: number;
  bubbleTailStyle: BubbleTailStyle;
}

export type KNKTNavTab = 'THREADS' | 'GROUPS' | 'MEDIA' | 'SETTINGS';
