import React, { useState } from 'react';
import { MessagingProvider, useMessaging } from './context/MessagingContext';
import { KNKTNavTab } from './types';
import { ThreadsScreen } from './screens/ThreadsScreen';
import { GroupsScreen } from './screens/GroupsScreen';
import { MediaBrowserScreen } from './screens/MediaBrowserScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { SecurityVaultScreen } from './screens/SecurityVaultScreen';
import { ChatThreadScreen } from './screens/ChatThreadScreen';
import { KNKTBottomDock } from './components/KNKTBottomDock';
import { NewDirectChatModal } from './screens/ThreadsScreen';
import { CreateGroupModal } from './screens/GroupsScreen';

const KNKTAppScaffold: React.FC = () => {
  const { createOrGetDirectConversation, createGroupConversation } = useMessaging();

  const [currentTab, setCurrentTab] = useState<KNKTNavTab>('THREADS');
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDockExpanded, setIsDockExpanded] = useState(false);
  const [isVaultOpen, setIsVaultOpen] = useState(false);

  // Dialog states triggered from the Navigation Dock
  const [showNewDirectChatDialog, setShowNewDirectChatDialog] = useState(false);
  const [showNewGroupChatDialog, setShowNewGroupChatDialog] = useState(false);

  // Swipe-to-peek interactive state: dragging left brings the chat thread in proportionally over the list
  const [peekConversationId, setPeekConversationId] = useState<number | null>(null);
  const [peekProgress, setPeekProgress] = useState(0);

  return (
    <div className="relative w-full min-h-screen bg-black text-white font-sans antialiased overflow-hidden select-none">
      {/* Security Vault Screen */}
      {isVaultOpen ? (
        <SecurityVaultScreen onBackClick={() => setIsVaultOpen(false)} />
      ) : (
        <>
          {/* Main Top-level Views (Threads, Groups, Media, Settings) */}
          <div className="w-full min-h-screen">
            {currentTab === 'THREADS' && (
              <ThreadsScreen
                searchQuery={searchQuery}
                onConversationClick={id => {
                  setPeekConversationId(null);
                  setActiveConversationId(id);
                }}
                showNewChatDialog={showNewDirectChatDialog}
                onDismissNewChatDialog={() => setShowNewDirectChatDialog(false)}
                onSwipeLeftPeek={(id, progress) => {
                  setPeekConversationId(id);
                  setPeekProgress(Math.max(0, Math.min(1, progress)));
                }}
                onNavigateToMedia={() => setCurrentTab('MEDIA')}
              />
            )}

            {currentTab === 'GROUPS' && (
              <GroupsScreen
                searchQuery={searchQuery}
                onConversationClick={id => {
                  setPeekConversationId(null);
                  setActiveConversationId(id);
                }}
                showCreateGroupDialog={showNewGroupChatDialog}
                onDismissCreateGroupDialog={() => setShowNewGroupChatDialog(false)}
                onSwipeLeftPeek={(id, progress) => {
                  setPeekConversationId(id);
                  setPeekProgress(Math.max(0, Math.min(1, progress)));
                }}
                onNavigateToMedia={() => setCurrentTab('MEDIA')}
              />
            )}

            {currentTab === 'MEDIA' && (
              <MediaBrowserScreen
                onShowInChat={id => {
                  setPeekConversationId(null);
                  setActiveConversationId(id);
                }}
              />
            )}

            {currentTab === 'SETTINGS' && (
              <SettingsScreen
                onOpenSecurityVault={() => setIsVaultOpen(true)}
              />
            )}
          </div>

          {/* Persistent Bottom Navigation Bubble (visible on home screen) */}
          {activeConversationId === null && (
            <KNKTBottomDock
              currentTab={currentTab}
              onTabSelected={tab => {
                setCurrentTab(tab);
                setIsVaultOpen(false);
              }}
              searchQuery={searchQuery}
              onSearchQueryChange={setSearchQuery}
              isExpanded={isDockExpanded}
              onToggleExpanded={() => setIsDockExpanded(!isDockExpanded)}
              onNewMessageClick={() => {
                setIsDockExpanded(false);
                if (currentTab === 'GROUPS') {
                  setShowNewGroupChatDialog(true);
                } else {
                  setShowNewDirectChatDialog(true);
                }
              }}
            />
          )}

          {/* Interactive Peek Overlay (slides in proportionally over the list when dragging left) */}
          {peekConversationId !== null && activeConversationId === null && (
            <div
              className="fixed inset-0 z-40 bg-black transition-transform duration-75"
              style={{
                transform: `translateX(${(1 - peekProgress) * 100}%)`,
              }}
            >
              <ChatThreadScreen
                conversationId={peekConversationId}
                onBackClick={() => {
                  setPeekConversationId(null);
                  setPeekProgress(0);
                }}
              />
            </div>
          )}

          {/* Active Conversation Full View */}
          {activeConversationId !== null && (
            <div className="fixed inset-0 z-40 bg-black animate-in slide-in-from-right-4 duration-200">
              <ChatThreadScreen
                conversationId={activeConversationId}
                onBackClick={() => setActiveConversationId(null)}
              />
            </div>
          )}
        </>
      )}

      {/* Direct Message Dialog from Dock */}
      {showNewDirectChatDialog && currentTab !== 'THREADS' && (
        <NewDirectChatModal
          onDismiss={() => setShowNewDirectChatDialog(false)}
          onStartChat={(name, phone, protocol, isEncrypted) => {
            setShowNewDirectChatDialog(false);
            const id = createOrGetDirectConversation(name, phone, protocol, isEncrypted);
            setActiveConversationId(id);
          }}
        />
      )}

      {/* Create Group Dialog from Dock */}
      {showNewGroupChatDialog && currentTab !== 'GROUPS' && (
        <CreateGroupModal
          onDismiss={() => setShowNewGroupChatDialog(false)}
          onCreateGroup={(groupName, memberList) => {
            setShowNewGroupChatDialog(false);
            const id = createGroupConversation(groupName, memberList);
            setActiveConversationId(id);
          }}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <MessagingProvider>
      <KNKTAppScaffold />
    </MessagingProvider>
  );
}
