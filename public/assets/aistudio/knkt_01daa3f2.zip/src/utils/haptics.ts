/**
 * Tactile Haptic & Audio Interaction Engine for KNKT
 * Implements refined vibration feedback patterns (simulating VibrationEffect)
 * for message sends, incoming notifications, and gesture interactions.
 */

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function playSubtleClick(freq: number = 800, duration: number = 0.015, volume: number = 0.05) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + duration);
  } catch {
    // Ignore audio autoplay restrictions
  }
}

export const HapticHelper = {
  /**
   * Subtle, crisp tick pattern when sending a message (simulates VibrationEffect.EFFECT_TICK)
   */
  messageSend() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        // Crisp 10ms micro-burst
        navigator.vibrate(10);
      } catch {}
    }
    playSubtleClick(1200, 0.018, 0.06);
  },

  /**
   * Crisp double pulse waveform pattern for incoming alerts and messages (simulates VibrationEffect.createWaveform)
   */
  incomingNotification() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        // Double pulse pattern: 25ms buzz, 35ms pause, 25ms buzz
        navigator.vibrate([25, 35, 25]);
      } catch {}
    }
    playSubtleClick(880, 0.035, 0.08);
  },

  /**
   * Micro-haptic texture feedback when swiping cards, peeking windows or sliding tabs
   */
  gestureSwipe() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        // Ultra-short 6ms tick
        navigator.vibrate(6);
      } catch {}
    }
    playSubtleClick(600, 0.01, 0.03);
  },

  /**
   * Firm, prominent haptic accent on long-pressing items for selection or thread settings (simulates VibrationEffect.EFFECT_HEAVY_CLICK)
   */
  longPress() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        // Firm 28ms pulse
        navigator.vibrate(28);
      } catch {}
    }
    playSubtleClick(360, 0.035, 0.08);
  },

  /**
   * Sharp, light click for emoji reactions and toggle chips (simulates VibrationEffect.EFFECT_CLICK)
   */
  reactionClick() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(8);
      } catch {}
    }
    playSubtleClick(1050, 0.016, 0.05);
  },

  /**
   * Pin toggle notification pattern (quick dual pulse)
   */
  pinToggle() {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate([12, 20, 16]);
      } catch {}
    }
    playSubtleClick(950, 0.02, 0.06);
  },
};
