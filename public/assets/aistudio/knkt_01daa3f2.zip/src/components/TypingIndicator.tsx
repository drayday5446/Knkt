import React from 'react';

interface TypingIndicatorProps {
  name: string;
  className?: string;
}

export const TypingIndicator: React.FC<TypingIndicatorProps> = ({ name, className = '' }) => {
  return (
    <div
      data-testid="typing_indicator_bubble"
      className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-[#0F0F14] border border-[#27272A] shadow-lg animate-in fade-in duration-200 ${className}`}
    >
      <span className="text-[11px] font-mono font-medium text-[#06B6D4]">
        {name}
      </span>
      <div className="flex items-center gap-1">
        <span className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-bounce [animation-delay:-0.3s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-bounce [animation-delay:-0.15s]" />
        <span className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-bounce" />
      </div>
    </div>
  );
};
