import React, { useState } from 'react';
import { Clock, Check, X } from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface ScheduleSendModalProps {
  messageText: string;
  onDismiss: () => void;
  onConfirmSchedule: (scheduledTimestamp: number) => void;
}

export const ScheduleSendModal: React.FC<ScheduleSendModalProps> = ({
  messageText,
  onDismiss,
  onConfirmSchedule,
}) => {
  const now = new Date();
  const defaultDate = new Date(now.getTime() + 60 * 60 * 1000);
  const formattedDefault = defaultDate.toISOString().slice(0, 16);

  const [customDateTime, setCustomDateTime] = useState(formattedDefault);
  const [selectedPreset, setSelectedPreset] = useState<number | 'CUSTOM'>(15 * 60 * 1000);

  const presets: { label: string; ms: number }[] = [
    { label: 'In 15 minutes', ms: 15 * 60 * 1000 },
    { label: 'In 1 hour', ms: 60 * 60 * 1000 },
    {
      label: 'Tomorrow 9:00 AM',
      ms: Math.max(60 * 1000, new Date(new Date().setHours(9, 0, 0, 0) + 24 * 3600 * 1000).getTime() - Date.now()),
    },
  ];

  const handleConfirm = () => {
    let targetTimestamp = Date.now();
    if (selectedPreset === 'CUSTOM') {
      const parsed = new Date(customDateTime).getTime();
      targetTimestamp = !isNaN(parsed) && parsed > Date.now() ? parsed : Date.now() + 60 * 60 * 1000;
    } else {
      targetTimestamp = Date.now() + selectedPreset;
    }

    HapticHelper.reactionClick();
    onConfirmSchedule(targetTimestamp);
  };

  return (
    <div
      data-testid="schedule_send_modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-sm rounded-[28px] bg-[#0A0A0E] border border-[#27272A] p-5 shadow-2xl animate-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-white font-mono">Schedule Send</h4>
              <p className="text-[10px] text-[#A1A1AA] font-mono">Auto-delivery dispatch</p>
            </div>
          </div>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Message preview snippet */}
        <div className="my-3 p-2.5 rounded-xl bg-[#141418] border border-[#27272A]">
          <span className="text-[10px] font-mono text-[#06B6D4] block mb-0.5">Payload Preview:</span>
          <p className="text-xs text-[#E4E4E7] font-mono truncate">&gt; {messageText}</p>
        </div>

        {/* Presets */}
        <div className="space-y-1.5 my-3">
          <span className="text-[10px] font-mono font-bold text-[#71717A] uppercase block px-1">
            Presets
          </span>
          {presets.map(p => {
            const ms = p.ms;
            const isSelected = selectedPreset === ms;
            return (
              <button
                key={p.label}
                onClick={() => {
                  setSelectedPreset(ms);
                  HapticHelper.reactionClick();
                }}
                className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-colors ${
                  isSelected
                    ? 'bg-[#06B6D4]/15 border-[#06B6D4] text-white font-bold'
                    : 'bg-[#121216] border-[#222226] text-[#A1A1AA] hover:text-white'
                }`}
              >
                <span className="text-xs font-mono">{p.label}</span>
                {isSelected && <Check className="w-4 h-4 text-[#06B6D4]" />}
              </button>
            );
          })}

          <button
            onClick={() => {
              setSelectedPreset('CUSTOM');
              HapticHelper.reactionClick();
            }}
            className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-colors ${
              selectedPreset === 'CUSTOM'
                ? 'bg-[#06B6D4]/15 border-[#06B6D4] text-white font-bold'
                : 'bg-[#121216] border-[#222226] text-[#A1A1AA] hover:text-white'
            }`}
          >
            <span className="text-xs font-mono">Custom Date & Time</span>
            {selectedPreset === 'CUSTOM' && <Check className="w-4 h-4 text-[#06B6D4]" />}
          </button>
        </div>

        {selectedPreset === 'CUSTOM' && (
          <div className="my-2 p-2 rounded-xl bg-[#141418] border border-[#27272A]">
            <input
              type="datetime-local"
              value={customDateTime}
              onChange={e => setCustomDateTime(e.target.value)}
              className="w-full bg-transparent text-white text-xs font-mono outline-none"
            />
          </div>
        )}

        <div className="flex items-center justify-end gap-2.5 mt-4 pt-3 border-t border-[#1E1E24]">
          <button
            onClick={onDismiss}
            className="px-3.5 py-1.5 rounded-xl text-xs font-mono text-[#A1A1AA] hover:text-white"
          >
            Cancel
          </button>
          <button
            data-testid="confirm_schedule_send_btn"
            onClick={handleConfirm}
            className="px-4 py-2 rounded-xl bg-[#06B6D4] hover:bg-[#22d3ee] text-black font-bold text-xs font-mono flex items-center gap-1.5 shadow-md active:scale-95"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Schedule</span>
          </button>
        </div>
      </div>
    </div>
  );
};
