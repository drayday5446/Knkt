import React, { useEffect, useState } from 'react';
import { ConversationEntity } from '../types';
import {
  Pin,
  PinOff,
  VolumeX,
  Volume2,
  Archive,
  Trash2,
  CheckSquare,
  X,
} from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface ThreadRadialMenuProps {
  conversation: ConversationEntity;
  onDismiss: () => void;
  onTogglePin: () => void;
  onToggleMute: () => void;
  onToggleArchive: () => void;
  onMoveToTrash: () => void;
  onEnterSelectMode: () => void;
}

export const ThreadRadialMenu: React.FC<ThreadRadialMenuProps> = ({
  conversation,
  onDismiss,
  onTogglePin,
  onToggleMute,
  onToggleArchive,
  onMoveToTrash,
  onEnterSelectMode,
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    HapticHelper.longPress();
  }, []);

  const items = [
    {
      id: 'pin',
      label: conversation.isPinned ? 'Unpin' : 'Pin',
      icon: conversation.isPinned ? PinOff : Pin,
      color: '#10B981',
      action: () => {
        HapticHelper.pinToggle();
        onTogglePin();
        onDismiss();
      },
    },
    {
      id: 'mute',
      label: conversation.isMuted ? 'Unmute' : 'Mute',
      icon: conversation.isMuted ? Volume2 : VolumeX,
      color: '#A855F7',
      action: () => {
        HapticHelper.reactionClick();
        onToggleMute();
        onDismiss();
      },
    },
    {
      id: 'archive',
      label: 'Archive',
      icon: Archive,
      color: '#F59E0B',
      action: () => {
        HapticHelper.reactionClick();
        onToggleArchive();
        onDismiss();
      },
    },
    {
      id: 'trash',
      label: 'Trash',
      icon: Trash2,
      color: '#EF4444',
      action: () => {
        HapticHelper.reactionClick();
        onMoveToTrash();
        onDismiss();
      },
    },
    {
      id: 'select',
      label: 'Select',
      icon: CheckSquare,
      color: '#06B6D4',
      action: () => {
        HapticHelper.reactionClick();
        onEnterSelectMode();
        onDismiss();
      },
    },
  ];

  const radius = 86;

  return (
    <div
      data-testid="thread_radial_menu_overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="relative flex items-center justify-center"
        onClick={e => e.stopPropagation()}
      >
        {/* Central Hub */}
        <div
          className={`w-20 h-20 rounded-full bg-[#0A0A0E] border-2 border-[#27272A] shadow-[0_0_30px_rgba(6,182,212,0.25)] flex flex-col items-center justify-center p-2 text-center transition-all duration-300 z-10 ${
            mounted ? 'scale-100 opacity-100' : 'scale-50 opacity-0'
          }`}
        >
          <span className="text-xs font-bold text-white truncate max-w-[64px] leading-tight font-mono">
            {conversation.recipientName}
          </span>
          <span className="text-[9px] font-mono text-[#06B6D4] mt-0.5">
            {conversation.isGroup ? 'GROUP' : conversation.activeProtocol}
          </span>
          <button
            onClick={onDismiss}
            className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#18181B] border border-[#3F3F46] flex items-center justify-center text-[#A1A1AA] hover:text-white"
          >
            <X className="w-3 h-3" />
          </button>
        </div>

        {/* Orbit Ring visual */}
        <div
          className={`absolute w-52 h-52 rounded-full border border-dashed border-[#27272A]/80 pointer-events-none transition-all duration-500 ${
            mounted ? 'scale-100 opacity-100' : 'scale-75 opacity-0'
          }`}
        />

        {/* Radial Satellite Buttons */}
        {items.map((item, index) => {
          const angle = (index * (360 / items.length) - 90) * (Math.PI / 180);
          const x = Math.round(Math.cos(angle) * radius);
          const y = Math.round(Math.sin(angle) * radius);
          const IconComp = item.icon;

          return (
            <div
              key={item.id}
              style={{
                transform: mounted
                  ? `translate(${x}px, ${y}px) scale(1)`
                  : 'translate(0px, 0px) scale(0)',
                transition: `all 260ms cubic-bezier(0.34, 1.56, 0.64, 1) ${index * 35}ms`,
              }}
              className="absolute z-20 flex flex-col items-center"
            >
              <button
                data-testid={`radial_action_${item.id}`}
                onClick={item.action}
                className="w-12 h-12 rounded-full bg-[#121216] border-2 shadow-xl flex items-center justify-center transition-transform hover:scale-115 active:scale-95 group"
                style={{
                  borderColor: item.color,
                  boxShadow: `0 0 14px ${item.color}35`,
                  color: item.color,
                }}
              >
                <IconComp className="w-5 h-5" />
              </button>
              <span
                className="text-[10px] font-mono font-bold tracking-wider mt-1 px-1.5 py-0.5 rounded bg-black/90 border border-white/10 shadow-md select-none"
                style={{ color: item.color }}
              >
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
