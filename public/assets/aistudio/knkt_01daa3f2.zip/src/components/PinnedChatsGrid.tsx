import React, { useRef } from 'react';
import { ConversationEntity } from '../types';
import { Pin, Check, VolumeX } from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface PinnedChatsGridProps {
  pinnedList: ConversationEntity[];
  selectedIds?: Set<number>;
  isSelectionMode?: boolean;
  onConversationClick: (id: number) => void;
  onConversationLongClick?: (id: number) => void;
}

export const PinnedChatsGrid: React.FC<PinnedChatsGridProps> = ({
  pinnedList,
  selectedIds = new Set(),
  isSelectionMode = false,
  onConversationClick,
  onConversationLongClick,
}) => {
  if (pinnedList.length === 0) return null;

  const getInitials = (name: string, isGroup: boolean): string => {
    if (isGroup) return '👥';
    const parts = name.split(' ').filter(Boolean);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase() || 'K';
  };

  const formatTime = (timestamp: number): string => {
    const d = new Date(timestamp);
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  const getPipColor = (conv: ConversationEntity): string => {
    if (conv.isE2EE) return '#06B6D4'; // Cyan E2EE
    if (conv.activeProtocol === 'MMS') return '#0284C7';
    return '#64748B'; // Slate Gray
  };

  return (
    <div className="w-full py-1" data-testid="pinned_chats_grid">
      <div className="flex items-center gap-1.5 mb-2">
        <Pin className="w-3.5 h-3.5 text-[#06B6D4]" />
        <span className="text-[11px] font-mono font-bold tracking-widest text-[#06B6D4]">
          PINNED ({pinnedList.length}/4)
        </span>
      </div>

      {pinnedList.length === 1 && (
        <BannerCard
          conv={pinnedList[0]}
          isSelected={selectedIds.has(pinnedList[0].id)}
          isSelectionMode={isSelectionMode}
          onClick={() => onConversationClick(pinnedList[0].id)}
          onLongClick={() => onConversationLongClick?.(pinnedList[0].id)}
          formatTime={formatTime}
          getPipColor={getPipColor}
          getInitials={getInitials}
        />
      )}

      {pinnedList.length === 2 && (
        <div className="grid grid-cols-2 gap-2.5">
          {pinnedList.map(conv => (
            <CompactCard
              key={conv.id}
              conv={conv}
              isSelected={selectedIds.has(conv.id)}
              isSelectionMode={isSelectionMode}
              onClick={() => onConversationClick(conv.id)}
              onLongClick={() => onConversationLongClick?.(conv.id)}
              formatTime={formatTime}
              getPipColor={getPipColor}
              getInitials={getInitials}
            />
          ))}
        </div>
      )}

      {pinnedList.length === 3 && (
        <div className="space-y-2.5">
          <div className="grid grid-cols-2 gap-2.5">
            {pinnedList.slice(0, 2).map(conv => (
              <CompactCard
                key={conv.id}
                conv={conv}
                isSelected={selectedIds.has(conv.id)}
                isSelectionMode={isSelectionMode}
                onClick={() => onConversationClick(conv.id)}
                onLongClick={() => onConversationLongClick?.(conv.id)}
                formatTime={formatTime}
                getPipColor={getPipColor}
                getInitials={getInitials}
              />
            ))}
          </div>
          <CompactCard
            conv={pinnedList[2]}
            isSelected={selectedIds.has(pinnedList[2].id)}
            isSelectionMode={isSelectionMode}
            onClick={() => onConversationClick(pinnedList[2].id)}
            onLongClick={() => onConversationLongClick?.(pinnedList[2].id)}
            formatTime={formatTime}
            getPipColor={getPipColor}
            getInitials={getInitials}
          />
        </div>
      )}

      {pinnedList.length >= 4 && (
        <div className="grid grid-cols-2 gap-2.5">
          {pinnedList.slice(0, 4).map(conv => (
            <CompactCard
              key={conv.id}
              conv={conv}
              isSelected={selectedIds.has(conv.id)}
              isSelectionMode={isSelectionMode}
              onClick={() => onConversationClick(conv.id)}
              onLongClick={() => onConversationLongClick?.(conv.id)}
              formatTime={formatTime}
              getPipColor={getPipColor}
              getInitials={getInitials}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface CardProps {
  conv: ConversationEntity;
  isSelected: boolean;
  isSelectionMode?: boolean;
  onClick: () => void;
  onLongClick?: () => void;
  formatTime: (t: number) => string;
  getPipColor: (c: ConversationEntity) => string;
  getInitials: (n: string, g: boolean) => string;
}

const BannerCard: React.FC<CardProps> = ({
  conv,
  isSelected,
  isSelectionMode,
  onClick,
  onLongClick,
  formatTime,
  getPipColor,
  getInitials,
}) => {
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const didLongPressRef = useRef(false);

  const startLongPress = () => {
    didLongPressRef.current = false;
    timerRef.current = setTimeout(() => {
      didLongPressRef.current = true;
      HapticHelper.longPress();
      onLongClick?.();
    }, 420);
  };

  const cancelLongPress = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  return (
    <div
      data-testid={`pinned_banner_card_${conv.id}`}
      onClick={e => {
        if (didLongPressRef.current) {
          e.stopPropagation();
          didLongPressRef.current = false;
          return;
        }
        onClick();
      }}
      onContextMenu={e => {
        e.preventDefault();
        HapticHelper.longPress();
        onLongClick?.();
      }}
      onTouchStart={startLongPress}
      onTouchEnd={cancelLongPress}
      onMouseDown={startLongPress}
      onMouseUp={cancelLongPress}
      onMouseLeave={cancelLongPress}
      className={`w-full rounded-3xl p-4 flex items-center gap-4 cursor-pointer transition-all border ${
        isSelected
          ? 'bg-[#141418] border-[#06B6D4] ring-1 ring-[#06B6D4]'
          : 'bg-[#0A0A0C] border-[#222226] hover:border-[#383840]'
      }`}
    >
      {isSelectionMode && (
        <div
          className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
            isSelected
              ? 'bg-[#06B6D4] border-[#06B6D4] text-black'
              : 'border-[#3F3F46] bg-[#141418]'
          }`}
        >
          {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
        </div>
      )}

      {/* Larger profile avatar */}
      <div
        className="w-[58px] h-[58px] rounded-full flex items-center justify-center shrink-0 font-bold text-lg text-white shadow-md"
        style={{ backgroundColor: conv.avatarColorHex }}
      >
        {getInitials(conv.recipientName, conv.isGroup)}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="font-bold text-[15px] text-white truncate">
              {conv.recipientName}
            </span>
            {conv.isMuted && <VolumeX className="w-3.5 h-3.5 text-[#71717A] shrink-0" />}
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <span
              className="w-1.5 h-1.5 rounded-full inline-block"
              style={{ backgroundColor: getPipColor(conv) }}
            />
            <span className="font-mono text-xs text-[#06B6D4]">
              {formatTime(conv.lastTimestamp)}
            </span>
          </div>
        </div>
        <p className="text-xs text-[#D4D4D8] line-clamp-2 mt-1 leading-snug">
          {conv.lastMessage}
        </p>
        {conv.unreadCount > 0 && (
          <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-[#06B6D4] text-black font-bold text-[10px] mt-1.5">
            {conv.unreadCount}
          </span>
        )}
      </div>
    </div>
  );
};

const CompactCard: React.FC<CardProps> = ({
  conv,
  isSelected,
  isSelectionMode,
  onClick,
  onLongClick,
  formatTime,
  getPipColor,
  getInitials,
}) => {
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const didLongPressRef = useRef(false);

  const startLongPress = () => {
    didLongPressRef.current = false;
    timerRef.current = setTimeout(() => {
      didLongPressRef.current = true;
      HapticHelper.longPress();
      onLongClick?.();
    }, 420);
  };

  const cancelLongPress = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  return (
    <div
      data-testid={`pinned_compact_card_${conv.id}`}
      onClick={e => {
        if (didLongPressRef.current) {
          e.stopPropagation();
          didLongPressRef.current = false;
          return;
        }
        onClick();
      }}
      onContextMenu={e => {
        e.preventDefault();
        HapticHelper.longPress();
        onLongClick?.();
      }}
      onTouchStart={startLongPress}
      onTouchEnd={cancelLongPress}
      onMouseDown={startLongPress}
      onMouseUp={cancelLongPress}
      onMouseLeave={cancelLongPress}
      className={`rounded-2xl p-3 cursor-pointer transition-all border flex flex-col justify-between ${
        isSelected
          ? 'bg-[#141418] border-[#06B6D4] ring-1 ring-[#06B6D4]'
          : 'bg-[#0A0A0C] border-[#222226] hover:border-[#383840]'
      }`}
    >
      <div className="flex items-center gap-2">
        {isSelectionMode && (
          <div
            className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
              isSelected
                ? 'bg-[#06B6D4] border-[#06B6D4] text-black'
                : 'border-[#3F3F46] bg-[#141418]'
            }`}
          >
            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
          </div>
        )}

        <div
          className="w-[36px] h-[36px] rounded-full flex items-center justify-center shrink-0 font-bold text-xs text-white shadow-sm"
          style={{ backgroundColor: conv.avatarColorHex }}
        >
          {getInitials(conv.recipientName, conv.isGroup)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[13px] text-white truncate block">
              {conv.recipientName}
            </span>
            {conv.unreadCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-[#06B6D4] text-black font-bold text-[9px] flex items-center justify-center shrink-0 ml-1">
                {conv.unreadCount}
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span
              className="w-1.5 h-1.5 rounded-full inline-block shrink-0"
              style={{ backgroundColor: getPipColor(conv) }}
            />
            <span className="font-mono text-[10px] text-[#A1A1AA] truncate">
              {formatTime(conv.lastTimestamp)}
            </span>
          </div>
        </div>
      </div>
      <p className="text-xs text-[#D4D4D8] truncate mt-2 leading-relaxed">
        {conv.lastMessage}
      </p>
    </div>
  );
};
