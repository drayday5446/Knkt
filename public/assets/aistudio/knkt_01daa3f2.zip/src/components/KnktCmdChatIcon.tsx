import React from 'react';

interface KnktCmdChatIconProps {
  size?: number;
  className?: string;
  glow?: boolean;
  accentColor?: string;
}

export const KnktCmdChatIcon: React.FC<KnktCmdChatIconProps> = ({
  size = 24,
  className = '',
  glow = true,
  accentColor = '#06B6D4',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`shrink-0 ${className}`}
    >
      <defs>
        {glow && (
          <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="0" stdDeviation="1.5" floodColor={accentColor} floodOpacity="0.6" />
          </filter>
        )}
      </defs>

      {/* Chat bubble outline and fill */}
      <path
        d="M6 8C6 5.79086 7.79086 4 10 4H22C24.2091 4 26 5.79086 26 8V18C26 20.2091 24.2091 22 22 22H13L7.5 26.5C6.8 27.1 6 26.6 6 25.7V22C6 22 6 22 6 22V8Z"
        fill="#0A0A0E"
        stroke={accentColor}
        strokeWidth="1.75"
        strokeLinejoin="round"
        strokeLinecap="round"
      />

      {/* Terminal CMD cursor prompt inside the bubble: >_ */}
      {/* Terminal Prompt arrow > */}
      <path
        d="M10.5 10L14 13L10.5 16"
        stroke={accentColor}
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        filter={glow ? 'url(#cyanGlow)' : undefined}
      />

      {/* CMD Block Cursor █ */}
      <rect
        x="16"
        y="10.5"
        width="4"
        height="5.5"
        rx="0.75"
        fill={accentColor}
        filter={glow ? 'url(#cyanGlow)' : undefined}
        className="animate-cmd-blink"
      />
    </svg>
  );
};
