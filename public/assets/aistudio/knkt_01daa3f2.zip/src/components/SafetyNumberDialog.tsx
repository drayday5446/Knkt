import React, { useState, useEffect, useRef } from 'react';
import { Shield, Copy, Check, X } from 'lucide-react';
import { generateKeyFingerprint, generateSafetyNumbers } from '../utils/crypto';
import { HapticHelper } from '../utils/haptics';

interface SafetyNumberDialogProps {
  contactName: string;
  contactPhone: string;
  isCurrentlyVerified: boolean;
  onDismiss: () => void;
  onVerificationChanged: (isVerified: boolean) => void;
}

export const SafetyNumberDialog: React.FC<SafetyNumberDialogProps> = ({
  contactName,
  contactPhone,
  isCurrentlyVerified,
  onDismiss,
  onVerificationChanged,
}) => {
  const [isVerified, setIsVerified] = useState(isCurrentlyVerified);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const safetyNumbers = generateSafetyNumbers(contactPhone);
  const fingerprint = generateKeyFingerprint(contactPhone);

  // Render a clean procedural QR-like verification matrix
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = canvas.width;
    const cells = 11;
    const cellSize = size / cells;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#0F172A';
    for (let r = 0; r < cells; r++) {
      for (let c = 0; c < cells; c++) {
        const isCorner =
          (r < 3 && c < 3) || (r < 3 && c > cells - 4) || (r > cells - 4 && c < 3);
        const shouldFill =
          isCorner ||
          ((r * 7 + c * 13 + contactPhone.charCodeAt((r + c) % contactPhone.length)) % 3 === 0);

        if (shouldFill) {
          ctx.fillRect(c * cellSize + 1, r * cellSize + 1, cellSize - 1.5, cellSize - 1.5);
        }
      }
    }
  }, [contactPhone]);

  const copySafetyNumbers = () => {
    navigator.clipboard.writeText(safetyNumbers);
    setCopied(true);
    HapticHelper.reactionClick();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      data-testid="safety_number_dialog"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md rounded-[28px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#06B6D4]/15 flex items-center justify-center text-[#06B6D4]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base leading-tight">
                Verify Safety Numbers
              </h3>
              <p className="text-xs text-[#A1A1AA]">{contactName}</p>
            </div>
          </div>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#A1A1AA] my-3 leading-relaxed text-center">
          Compare these safety numbers with {contactName} to verify that your messages are
          end-to-end encrypted without an interception vector.
        </p>

        {/* Procedural QR Code Visual */}
        <div className="flex justify-center my-3">
          <div className="p-3 bg-white rounded-2xl shadow-md">
            <canvas ref={canvasRef} width={120} height={120} className="block" />
          </div>
        </div>

        {/* Safety numbers display */}
        <div className="p-3.5 rounded-xl bg-[#141418] border border-[#27272A] text-center my-3">
          <div className="font-mono font-bold text-base tracking-wider text-white">
            {safetyNumbers}
          </div>
          <div className="font-mono text-[10px] text-[#06B6D4] mt-1 break-all">
            {fingerprint}
          </div>
        </div>

        {/* Verified Switch */}
        <div className="p-3.5 rounded-xl bg-[#141418]/60 border border-[#27272A] flex items-center justify-between my-3">
          <div>
            <div className="text-xs font-semibold text-white">Mark as Verified</div>
            <div
              className={`text-[11px] ${
                isVerified ? 'text-[#10B981] font-medium' : 'text-[#71717A]'
              }`}
            >
              {isVerified ? 'Identity verified & trusted' : 'Unverified identity'}
            </div>
          </div>
          <button
            data-testid="verify_contact_switch"
            onClick={() => {
              const next = !isVerified;
              setIsVerified(next);
              onVerificationChanged(next);
              HapticHelper.reactionClick();
            }}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              isVerified ? 'bg-[#10B981]' : 'bg-[#27272A]'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                isVerified ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>

        {/* Copy button */}
        <button
          data-testid="copy_safety_num_btn"
          onClick={copySafetyNumbers}
          className="w-full py-2.5 px-4 rounded-xl border border-[#27272A] hover:border-[#06B6D4] text-xs font-mono font-medium text-white flex items-center justify-center gap-2 bg-[#121216] transition-colors mt-2"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-[#10B981]" />
              <span className="text-[#10B981]">Safety Numbers Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-[#06B6D4]" />
              <span>Copy Safety Numbers</span>
            </>
          )}
        </button>

        {/* Done */}
        <div className="flex justify-end mt-4 pt-3 border-t border-[#1E1E24]">
          <button
            data-testid="safety_done_btn"
            onClick={onDismiss}
            className="px-6 py-2 rounded-xl bg-[#06B6D4] hover:bg-[#22d3ee] text-black font-bold text-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
