import React from 'react';
import { KNKTNavTab } from '../types';
import {
  MessageSquare,
  Users,
  Film,
  Settings,
  Edit,
  Search,
  X,
} from 'lucide-react';
import { KnktCmdChatIcon } from './KnktCmdChatIcon';
import { HapticHelper } from '../utils/haptics';

interface KNKTBottomDockProps {
  currentTab: KNKTNavTab;
  onTabSelected: (tab: KNKTNavTab) => void;
  searchQuery: string;
  onSearchQueryChange: (query: string) => void;
  isExpanded: boolean;
  onToggleExpanded: () => void;
  onNewMessageClick: () => void;
  className?: string;
}

export const KNKTBottomDock: React.FC<KNKTBottomDockProps> = ({
  currentTab,
  onTabSelected,
  searchQuery,
  onSearchQueryChange,
  isExpanded,
  onToggleExpanded,
  onNewMessageClick,
  className = '',
}) => {
  const tabs: { id: KNKTNavTab; title: string; icon: React.ElementType }[] = [
    { id: 'THREADS', title: 'Threads', icon: MessageSquare },
    { id: 'GROUPS', title: 'Groups', icon: Users },
    { id: 'MEDIA', title: 'Media', icon: Film },
    { id: 'SETTINGS', title: 'Settings', icon: Settings },
  ];

  return (
    <div
      className={`fixed bottom-5 left-0 right-0 z-50 flex flex-col items-center pointer-events-none px-4 ${className}`}
    >
      <div className="w-full max-w-md pointer-events-auto flex flex-col items-center">
        {/* Expanded Navigation & Action Sheet */}
        {isExpanded && (
          <div
            data-testid="knkt_expanded_dock"
            className="w-full mb-3 rounded-[28px] bg-black border border-[#27272A] p-4 shadow-[0_12px_40px_rgba(0,0,0,0.85)] animate-in fade-in slide-in-from-bottom-6 duration-200"
          >
            {/* "New Message / Chat" Button - Placed directly above the tab options as requested */}
            <button
              data-testid="dock_new_message_btn"
              onClick={() => {
                HapticHelper.messageSend();
                onNewMessageClick();
              }}
              className="w-full py-3 px-4 rounded-2xl bg-[#06B6D4] text-black font-bold text-sm flex items-center justify-center gap-2 hover:bg-[#22d3ee] transition-colors shadow-lg active:scale-[0.98]"
            >
              <Edit className="w-4 h-4 stroke-[2.5]" />
              <span>
                {currentTab === 'GROUPS' ? 'New Group Chat' : 'New Message'}
              </span>
            </button>

            {/* Options Row: Threads, Groups, Media, Settings */}
            <div className="grid grid-cols-4 gap-2 my-3.5">
              {tabs.map(tab => {
                const isSelected = currentTab === tab.id;
                const IconComp = tab.icon;
                return (
                  <button
                    key={tab.id}
                    data-testid={`dock_tab_${tab.id.toLowerCase()}`}
                    onClick={() => {
                      HapticHelper.gestureSwipe();
                      onTabSelected(tab.id);
                      onToggleExpanded();
                    }}
                    className="flex flex-col items-center gap-1.5 p-1 rounded-2xl transition-all group"
                  >
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-[#06B6D4]/20 border border-[#06B6D4] text-[#06B6D4]'
                          : 'bg-[#121216] text-[#A1A1AA] hover:text-white border border-transparent'
                      }`}
                    >
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span
                      className={`text-[11px] font-medium tracking-wide ${
                        isSelected ? 'font-bold text-[#06B6D4]' : 'text-[#A1A1AA]'
                      }`}
                    >
                      {tab.title}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Search Bar just beneath options */}
            <div className="relative w-full">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#06B6D4]" />
              <input
                data-testid="dock_search_bar"
                type="text"
                value={searchQuery}
                onChange={e => onSearchQueryChange(e.target.value)}
                placeholder="Search messages, groups, media..."
                className="w-full pl-10 pr-9 py-2.5 rounded-[18px] bg-[#0D0D10] border border-[#27272A] focus:border-[#06B6D4] text-white placeholder-[#71717A] text-xs font-mono outline-none transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchQueryChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#71717A] hover:text-white"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Condensed Bubble Icon at bottom middle */}
        <button
          data-testid="knkt_dock_bubble_trigger"
          onClick={() => {
            HapticHelper.gestureSwipe();
            onToggleExpanded();
          }}
          className={`w-[56px] h-[56px] rounded-full bg-black border-2 flex items-center justify-center shadow-2xl transition-all active:scale-95 group ${
            isExpanded
              ? 'border-[#06B6D4] text-white shadow-[#06B6D4]/30'
              : 'border-[#27272A] hover:border-[#06B6D4] text-[#06B6D4] shadow-black'
          }`}
          aria-label="Toggle Navigation Dock"
        >
          {isExpanded ? (
            <X className="w-6 h-6 stroke-[2.5]" />
          ) : (
            <KnktCmdChatIcon size={26} glow={true} />
          )}
        </button>
      </div>
    </div>
  );
};
