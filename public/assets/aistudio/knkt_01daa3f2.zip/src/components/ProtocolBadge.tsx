import React from 'react';
import { MessageProtocolType, PROTOCOL_CONFIGS } from '../types';
import { MessageSquare, Paperclip, Zap, Shield, Lock } from 'lucide-react';

interface ProtocolBadgeProps {
  protocol: MessageProtocolType;
  isSmall?: boolean;
  className?: string;
}

export const ProtocolBadge: React.FC<ProtocolBadgeProps> = ({ protocol, isSmall = false, className = '' }) => {
  const config = PROTOCOL_CONFIGS[protocol] || PROTOCOL_CONFIGS.RCS;

  const IconComponent =
    protocol === 'SMS' ? MessageSquare : protocol === 'MMS' ? Paperclip : Zap;

  return (
    <div
      data-testid={`protocol_badge_${protocol.toLowerCase()}`}
      className={`inline-flex items-center gap-1 font-mono font-bold tracking-wider rounded-full transition-colors ${
        isSmall ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1'
      } ${className}`}
      style={{
        backgroundColor: `${config.badgeColor}25`,
        color: config.badgeColor,
        border: `1px solid ${config.badgeColor}40`,
      }}
    >
      <IconComponent className={isSmall ? 'w-2.5 h-2.5' : 'w-3 h-3'} />
      <span>{config.label}</span>
    </div>
  );
};

export const E2EELockBadge: React.FC<{ isVerified?: boolean; isSmall?: boolean }> = ({
  isVerified = true,
  isSmall = false,
}) => {
  const color = isVerified ? '#10B981' : '#F59E0B';

  return (
    <div
      data-testid="e2ee_badge"
      className={`inline-flex items-center gap-1 font-mono font-bold rounded-full ${
        isSmall ? 'text-[9px] px-2 py-0.5' : 'text-[11px] px-2.5 py-1'
      }`}
      style={{
        backgroundColor: `${color}20`,
        color,
        border: `1px solid ${color}45`,
      }}
    >
      {isVerified ? (
        <Shield className={isSmall ? 'w-2.5 h-2.5' : 'w-3 h-3'} />
      ) : (
        <Lock className={isSmall ? 'w-2.5 h-2.5' : 'w-3 h-3'} />
      )}
      <span>{isVerified ? 'E2EE' : 'ENCRYPTED'}</span>
    </div>
  );
};
