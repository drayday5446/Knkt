import React, { useState, useRef } from 'react';
import { ConversationEntity, SwipeRightAction } from '../types';
import {
  Check,
  ArrowRight,
  Mail,
  MailCheck,
  Archive,
  Trash2,
  Pin,
  VolumeX,
} from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface SwipeableConversationCardProps {
  conversation: ConversationEntity;
  swipeRightAction: SwipeRightAction;
  isSelected?: boolean;
  isSelectionMode?: boolean;
  onClick: () => void;
  onLongClick: () => void;
  onSwipeLeftPeek?: (dragProgress: Float32Array | number) => void;
  onSwipeLeftComplete: () => void;
  onSwipeRight: () => void;
  className?: string;
}

export const SwipeableConversationCard: React.FC<SwipeableConversationCardProps> = ({
  conversation,
  swipeRightAction,
  isSelected = false,
  isSelectionMode = false,
  onClick,
  onLongClick,
  onSwipeLeftPeek,
  onSwipeLeftComplete,
  onSwipeRight,
  className = '',
}) => {
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const currentXRef = useRef(0);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const didTriggerLongPressRef = useRef(false);

  const getInitials = (name: string, isGroup: boolean): string => {
    if (isGroup) return '👥';
    const parts = name.split(' ').filter(Boolean);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.slice(0, 2).toUpperCase() || 'K';
  };

  const formatTime = (timestamp: number): string => {
    const d = new Date(timestamp);
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  };

  const minimalProtocolPipColor = conversation.isE2EE
    ? '#06B6D4' // Neon Cyan (E2EE)
    : conversation.activeProtocol === 'MMS'
    ? '#0284C7' // Sky
    : '#64748B'; // Slate Gray

  const getRightActionDetails = () => {
    switch (swipeRightAction) {
      case 'MARK_READ_UNREAD':
        return {
          icon: conversation.unreadCount > 0 ? MailCheck : Mail,
          color: '#38BDF8',
          label: conversation.unreadCount > 0 ? 'Mark Read' : 'Mark Unread',
        };
      case 'ARCHIVE':
        return {
          icon: Archive,
          color: '#F59E0B',
          label: 'Archive',
        };
      case 'TRASH':
        return {
          icon: Trash2,
          color: '#EF4444',
          label: 'Trash',
        };
      case 'PIN':
        return {
          icon: Pin,
          color: '#10B981',
          label: conversation.isPinned ? 'Unpin' : 'Pin',
        };
    }
  };

  const rightAction = getRightActionDetails();
  const RightIcon = rightAction.icon;

  const handlePointerDown = (clientX: number) => {
    didTriggerLongPressRef.current = false;
    startXRef.current = clientX;
    currentXRef.current = clientX;
    setIsDragging(true);

    longPressTimer.current = setTimeout(() => {
      didTriggerLongPressRef.current = true;
      HapticHelper.longPress();
      onLongClick();
    }, 420);
  };

  const handlePointerMove = (clientX: number) => {
    if (!isDragging) return;
    currentXRef.current = clientX;
    const delta = clientX - startXRef.current;

    if (Math.abs(delta) > 8 && longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }

    if (!isSelectionMode) {
      setDragOffset(delta);
      if (delta < 0 && onSwipeLeftPeek) {
        const progress = Math.min(1, Math.abs(delta) / 280);
        onSwipeLeftPeek(progress);
      }
    }
  };

  const handlePointerUp = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }

    if (!isDragging) return;
    setIsDragging(false);

    if (didTriggerLongPressRef.current) {
      setDragOffset(0);
      return;
    }

    if (!isSelectionMode) {
      if (dragOffset < -90) {
        // Swiped left sufficiently -> Trigger Peek / Enter
        HapticHelper.gestureSwipe();
        onSwipeLeftComplete();
      } else if (dragOffset > 90) {
        // Swiped right -> Trigger right action
        HapticHelper.gestureSwipe();
        onSwipeRight();
      }
    }

    setDragOffset(0);
  };

  const handleClick = (e: React.MouseEvent) => {
    if (didTriggerLongPressRef.current) {
      e.stopPropagation();
      didTriggerLongPressRef.current = false;
      return;
    }
    onClick();
  };

  return (
    <div
      data-testid={`swipeable_conv_${conversation.id}`}
      className={`relative w-full rounded-[22px] overflow-hidden select-none ${className}`}
    >
      {/* Background action reveals (hidden in selection mode) */}
      {!isSelectionMode && (
        <div className="absolute inset-0 bg-black flex items-center justify-between px-5">
          {/* Right swipe action (left side reveals right action) */}
          <div
            className="flex items-center gap-2 transition-opacity"
            style={{
              opacity: dragOffset > 25 ? Math.min(1, dragOffset / 80) : 0,
              color: rightAction.color,
            }}
          >
            <RightIcon className="w-5 h-5" />
            <span className="text-xs font-bold font-mono">{rightAction.label}</span>
          </div>

          {/* Left swipe action (right side reveals Peek) */}
          <div
            className="flex items-center gap-1.5 transition-opacity"
            style={{
              opacity: dragOffset < -25 ? Math.min(1, -dragOffset / 80) : 0,
              color: '#06B6D4',
            }}
          >
            <span className="text-xs font-bold font-mono">Peek</span>
            <ArrowRight className="w-5 h-5" />
          </div>
        </div>
      )}

      {/* Foreground card */}
      <div
        style={{
          transform: isSelectionMode ? 'none' : `translateX(${dragOffset}px)`,
          transition: isDragging ? 'none' : 'transform 0.22s ease-out',
        }}
        onClick={handleClick}
        onContextMenu={e => {
          e.preventDefault();
          HapticHelper.longPress();
          onLongClick();
        }}
        onTouchStart={e => handlePointerDown(e.touches[0].clientX)}
        onTouchMove={e => handlePointerMove(e.touches[0].clientX)}
        onTouchEnd={handlePointerUp}
        onMouseDown={e => handlePointerDown(e.clientX)}
        onMouseMove={e => handlePointerMove(e.clientX)}
        onMouseUp={handlePointerUp}
        onMouseLeave={handlePointerUp}
        className={`relative z-10 w-full rounded-[22px] p-3 flex items-center gap-3 cursor-pointer border transition-colors ${
          isSelected
            ? 'bg-[#131722] border-[#06B6D4] ring-1 ring-[#06B6D4]'
            : 'bg-[#0A0A0C] border-[#1E1E22] hover:border-[#2D2D35]'
        }`}
      >
        {/* Checkbox when in Selection Mode */}
        {isSelectionMode && (
          <div
            className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
              isSelected
                ? 'bg-[#06B6D4] border-[#06B6D4] text-black'
                : 'border-[#3F3F46] bg-[#141418]'
            }`}
          >
            {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
          </div>
        )}

        {/* Profile Avatar */}
        <div className="relative shrink-0">
          <div
            className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-white shadow-sm"
            style={{ backgroundColor: conversation.avatarColorHex }}
          >
            <span className={conversation.isGroup ? 'text-base' : 'text-sm'}>
              {getInitials(conversation.recipientName, conversation.isGroup)}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0">
              <span
                className={`text-[14px] truncate ${
                  conversation.unreadCount > 0
                    ? 'font-bold text-white'
                    : 'font-semibold text-white/90'
                }`}
              >
                {conversation.recipientName}
              </span>
              {conversation.isMuted && (
                <VolumeX className="w-3.5 h-3.5 text-[#71717A] shrink-0" />
              )}
            </div>

            {/* Time and minimal unintrusive pip */}
            <div className="flex items-center gap-1.5 shrink-0">
              <span
                className="w-1.5 h-1.5 rounded-full inline-block shrink-0 shadow-sm"
                style={{ backgroundColor: minimalProtocolPipColor }}
              />
              <span
                className={`font-mono text-[11px] ${
                  conversation.unreadCount > 0 ? 'text-[#06B6D4] font-medium' : 'text-[#A1A1AA]'
                }`}
              >
                {formatTime(conversation.lastTimestamp)}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 mt-0.5">
            <p
              className={`text-xs truncate ${
                conversation.unreadCount > 0
                  ? 'text-white font-medium'
                  : 'text-[#A1A1AA]'
              }`}
            >
              {conversation.lastMessage}
            </p>
            {conversation.unreadCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-[#06B6D4] text-black font-bold text-[9px] flex items-center justify-center shrink-0">
                {conversation.unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
