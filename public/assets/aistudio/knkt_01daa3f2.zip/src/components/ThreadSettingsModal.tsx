import React from 'react';
import { ConversationEntity } from '../types';
import {
  Pin,
  PinOff,
  Mail,
  MailCheck,
  Archive,
  Trash2,
  Palette,
  Shield,
  X,
} from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface ThreadSettingsModalProps {
  conversation: ConversationEntity;
  onDismiss: () => void;
  onTogglePin: () => void;
  onToggleRead: () => void;
  onToggleArchive: () => void;
  onMoveToTrash: () => void;
  onOpenCustomizer: () => void;
  onOpenSafetyNumbers: () => void;
}

export const ThreadSettingsModal: React.FC<ThreadSettingsModalProps> = ({
  conversation,
  onDismiss,
  onTogglePin,
  onToggleRead,
  onToggleArchive,
  onMoveToTrash,
  onOpenCustomizer,
  onOpenSafetyNumbers,
}) => {
  return (
    <div
      data-testid="thread_quick_settings_modal"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-sm rounded-[28px] bg-[#0A0A0E] border border-[#27272A] p-5 shadow-2xl animate-in slide-in-from-bottom duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm shrink-0"
              style={{ backgroundColor: conversation.avatarColorHex }}
            >
              {conversation.isGroup
                ? '👥'
                : (conversation.recipientName[0] || 'K').toUpperCase()}
            </div>
            <div className="min-w-0">
              <h4 className="font-bold text-sm text-white truncate">
                {conversation.recipientName}
              </h4>
              <p className="text-[11px] font-mono text-[#A1A1AA] truncate">
                {conversation.isGroup
                  ? `${conversation.groupParticipants?.split(',').length || 3} members`
                  : conversation.recipientPhone}
              </p>
            </div>
          </div>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action items */}
        <div className="space-y-1.5 my-3.5">
          {/* Pin / Unpin */}
          <button
            data-testid="thread_setting_pin_btn"
            onClick={() => {
              HapticHelper.pinToggle();
              onTogglePin();
              onDismiss();
            }}
            className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-[#10B981]/15 text-[#10B981] flex items-center justify-center shrink-0">
              {conversation.isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
            </div>
            <div>
              <span className="text-xs font-semibold text-white block">
                {conversation.isPinned ? 'Unpin Thread' : 'Pin to Top (Grid)'}
              </span>
              <span className="text-[10px] text-[#71717A]">
                {conversation.isPinned ? 'Remove from pinned cards' : 'Keep pinned on OLED dashboard'}
              </span>
            </div>
          </button>

          {/* Mark Read / Unread */}
          <button
            data-testid="thread_setting_read_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onToggleRead();
              onDismiss();
            }}
            className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-[#38BDF8]/15 text-[#38BDF8] flex items-center justify-center shrink-0">
              {conversation.unreadCount > 0 ? (
                <MailCheck className="w-4 h-4" />
              ) : (
                <Mail className="w-4 h-4" />
              )}
            </div>
            <div>
              <span className="text-xs font-semibold text-white block">
                {conversation.unreadCount > 0 ? 'Mark as Read' : 'Mark as Unread'}
              </span>
              <span className="text-[10px] text-[#71717A]">
                Toggle unread badge count
              </span>
            </div>
          </button>

          {/* Archive */}
          <button
            data-testid="thread_setting_archive_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onToggleArchive();
              onDismiss();
            }}
            className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-[#F59E0B]/15 text-[#F59E0B] flex items-center justify-center shrink-0">
              <Archive className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-white block">
                Archive Conversation
              </span>
              <span className="text-[10px] text-[#71717A]">
                Hide from list until new message arrives
              </span>
            </div>
          </button>

          {/* Customize Bubble Theming */}
          <button
            data-testid="thread_setting_theme_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onDismiss();
              onOpenCustomizer();
            }}
            className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-[#06B6D4]/15 text-[#06B6D4] flex items-center justify-center shrink-0">
              <Palette className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-white block">
                Customize Bubble Theming
              </span>
              <span className="text-[10px] text-[#71717A]">
                Change bubble shape, neon colors & participants
              </span>
            </div>
          </button>

          {/* Verify Safety Numbers */}
          {!conversation.isGroup && (
            <button
              data-testid="thread_setting_safety_btn"
              onClick={() => {
                HapticHelper.reactionClick();
                onDismiss();
                onOpenSafetyNumbers();
              }}
              className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
            >
              <div className="w-8 h-8 rounded-lg bg-[#10B981]/15 text-[#10B981] flex items-center justify-center shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-semibold text-white block">
                  Verify Safety Numbers
                </span>
                <span className="text-[10px] text-[#71717A]">
                  Review E2EE cryptographic keys & QR matrix
                </span>
              </div>
            </button>
          )}

          {/* Move to Trash */}
          <button
            data-testid="thread_setting_trash_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onMoveToTrash();
              onDismiss();
            }}
            className="w-full p-2.5 rounded-xl bg-[#141418] hover:bg-[#1E1E24] border border-[#27272A] flex items-center gap-3 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-[#EF4444]/15 text-[#EF4444] flex items-center justify-center shrink-0">
              <Trash2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#EF4444] block">
                Move to Trash
              </span>
              <span className="text-[10px] text-[#71717A]">
                Soft-delete conversation (recoverable in Settings)
              </span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
