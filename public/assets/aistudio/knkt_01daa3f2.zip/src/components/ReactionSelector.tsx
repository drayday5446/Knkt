import React from 'react';
import { HapticHelper } from '../utils/haptics';

interface ReactionSelectorProps {
  onSelectReaction: (emoji: string | null) => void;
  currentReaction?: string;
  className?: string;
}

export const ReactionSelector: React.FC<ReactionSelectorProps> = ({
  onSelectReaction,
  currentReaction,
  className = '',
}) => {
  const reactions = ['❤️', '👍', '😂', '😮', '😢', '🔥'];

  return (
    <div
      data-testid="reaction_selector_bar"
      className={`inline-flex items-center gap-1.5 p-1.5 rounded-full bg-[#121216] border border-[#27272A] shadow-xl ${className}`}
    >
      {reactions.map(emoji => {
        const isSelected = currentReaction === emoji;
        return (
          <button
            key={emoji}
            data-testid={`reaction_${emoji}`}
            onClick={() => {
              HapticHelper.reactionClick();
              onSelectReaction(isSelected ? null : emoji);
            }}
            className={`w-9 h-9 rounded-full flex items-center justify-center text-lg transition-transform hover:scale-125 active:scale-95 ${
              isSelected ? 'bg-[#06B6D4]/25 ring-1 ring-[#06B6D4]' : 'hover:bg-white/10'
            }`}
          >
            <span>{emoji}</span>
          </button>
        );
      })}
    </div>
  );
};
