import React, { useState } from 'react';
import { MessageEntity } from '../types';
import { Shield, Copy, Check, X } from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface CryptoInspectorDialogProps {
  message: MessageEntity;
  contactName: string;
  onDismiss: () => void;
  onVerifyContactClick: () => void;
}

export const CryptoInspectorDialog: React.FC<CryptoInspectorDialogProps> = ({
  message,
  contactName,
  onDismiss,
  onVerifyContactClick,
}) => {
  const [copied, setCopied] = useState(false);

  const copyCiphertext = () => {
    if (message.cipherTextBase64) {
      navigator.clipboard.writeText(message.cipherTextBase64);
      setCopied(true);
      HapticHelper.reactionClick();
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div
      data-testid="crypto_inspector_dialog"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div className="w-full max-w-md rounded-[28px] bg-[#0A0A0E] border border-[#27272A] p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#1E1E24]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#10B981]/15 flex items-center justify-center text-[#10B981]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base leading-tight">
                E2EE Cryptographic Packet
              </h3>
              <p className="text-xs text-[#A1A1AA]">Secured with {contactName}</p>
            </div>
          </div>
          <button
            onClick={onDismiss}
            className="text-[#71717A] hover:text-white p-1 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Description */}
        <p className="text-xs text-[#A1A1AA] my-3 leading-relaxed">
          This message was encrypted on your device using AES-256 in Galois/Counter Mode (GCM)
          with authenticated integrity verification.
        </p>

        {/* Cryptographic metadata rows */}
        <div className="space-y-2.5 my-4">
          <div className="p-3 rounded-xl bg-[#141418] border border-[#27272A]">
            <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-0.5">
              Protocol Standard
            </span>
            <span className="text-xs text-white">
              RCS Universal Profile + Signal Ratchet
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#141418] border border-[#27272A]">
            <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-0.5">
              Cipher Suite
            </span>
            <span className="text-xs text-white">
              AES-256-GCM / 128-bit MAC Tag
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#141418] border border-[#27272A]">
            <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-0.5">
              Initialization Vector (IV)
            </span>
            <span className="font-mono text-xs text-white break-all">
              {message.ivHex || '7A 4F 12 99 BC 01 E3 88 56 F2 00 3C'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#141418] border border-[#27272A]">
            <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-0.5">
              GCM Auth Tag
            </span>
            <span className="font-mono text-xs text-white break-all">
              {message.tagHex || 'B9 10 44 AA F1 C2 33 89'}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-[#141418] border border-[#27272A]">
            <span className="block text-[10px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-0.5">
              Ciphertext (Payload)
            </span>
            <span className="font-mono text-xs text-white break-all line-clamp-3">
              {message.cipherTextBase64 || 'kL92mGvP198B7k== [Simulated Encrypted Block]'}
            </span>
          </div>
        </div>

        {/* Copy button */}
        <button
          data-testid="copy_ciphertext_btn"
          onClick={copyCiphertext}
          className="w-full py-2.5 px-4 rounded-xl border border-[#27272A] hover:border-[#06B6D4] text-xs font-mono font-medium text-white flex items-center justify-center gap-2 bg-[#121216] transition-colors"
        >
          {copied ? (
            <>
              <Check className="w-4 h-4 text-[#10B981]" />
              <span className="text-[#10B981]">Copied to Clipboard</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4 text-[#06B6D4]" />
              <span>Copy Raw Ciphertext</span>
            </>
          )}
        </button>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 mt-5 pt-3 border-t border-[#1E1E24]">
          <button
            data-testid="verify_keys_btn"
            onClick={() => {
              onDismiss();
              onVerifyContactClick();
            }}
            className="px-4 py-2 text-xs font-semibold text-[#06B6D4] hover:underline"
          >
            Verify Safety Numbers
          </button>
          <button
            data-testid="crypto_close_btn"
            onClick={onDismiss}
            className="px-5 py-2 rounded-xl bg-[#06B6D4] hover:bg-[#22d3ee] text-black font-bold text-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
