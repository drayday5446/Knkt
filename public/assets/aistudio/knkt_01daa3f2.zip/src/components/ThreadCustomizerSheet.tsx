import React, { useState } from 'react';
import { ConversationEntity, BubbleShapeType } from '../types';
import { X, Check } from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface ThreadCustomizerSheetProps {
  conversation: ConversationEntity;
  onDismiss: () => void;
  onSaveTheming: (
    userColor?: string,
    peerColor?: string,
    userShape?: BubbleShapeType,
    peerShape?: BubbleShapeType,
    bgUri?: string,
    groupConfig?: string
  ) => void;
}

export const ThreadCustomizerSheet: React.FC<ThreadCustomizerSheetProps> = ({
  conversation,
  onDismiss,
  onSaveTheming,
}) => {
  const [selectedUserColor, setSelectedUserColor] = useState(
    conversation.customUserBubbleColor || '#06B6D4'
  );
  const [selectedPeerColor, setSelectedPeerColor] = useState(
    conversation.customPeerBubbleColor || '#18181B'
  );
  const [selectedUserShape, setSelectedUserShape] = useState<BubbleShapeType>(
    conversation.customUserBubbleShape || 'ROUNDED'
  );
  const [selectedPeerShape, setSelectedPeerShape] = useState<BubbleShapeType>(
    conversation.customPeerBubbleShape || 'ROUNDED'
  );

  const paletteOptions = [
    '#06B6D4', // Cyan
    '#3B82F6', // Royal Blue
    '#10B981', // Emerald
    '#A855F7', // Purple
    '#F97316', // Orange
    '#EF4444', // Red
    '#18181B', // Pitch Dark
  ];

  const shapes: { type: BubbleShapeType; label: string }[] = [
    { type: 'ROUNDED', label: 'Squircle' },
    { type: 'RECTANGULAR', label: 'Sharp' },
    { type: 'PILL', label: 'Pill' },
    { type: 'CHAT_TAIL', label: 'Tail' },
  ];

  // Group participants map
  const members = conversation.isGroup
    ? conversation.groupParticipants?.split(',').map(s => s.trim()) || []
    : [];

  const [memberConfigs, setMemberConfigs] = useState<
    Record<string, { color: string; shape: BubbleShapeType }>
  >(() => {
    const map: Record<string, { color: string; shape: BubbleShapeType }> = {};
    if (conversation.groupBubbleConfigJson) {
      conversation.groupBubbleConfigJson.split(';').forEach(entry => {
        const parts = entry.split('|');
        if (parts.length >= 3) {
          map[parts[0]] = {
            color: parts[1],
            shape: (parts[2] as BubbleShapeType) || 'ROUNDED',
          };
        }
      });
    }
    return map;
  });

  const handleApply = () => {
    HapticHelper.reactionClick();
    let groupConfigStr: string | undefined = undefined;

    if (conversation.isGroup) {
      groupConfigStr = Object.entries(memberConfigs)
        .map(([name, conf]) => `${name}|${conf.color}|${conf.shape}`)
        .join(';');
    }

    onSaveTheming(
      selectedUserColor,
      selectedPeerColor,
      selectedUserShape,
      selectedPeerShape,
      undefined,
      groupConfigStr
    );
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-lg rounded-t-[32px] bg-[#0A0A0E] border-t border-x border-[#27272A] p-6 shadow-2xl max-h-[85vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
          <div>
            <h3 className="font-bold text-white text-lg">
              Customize {conversation.isGroup ? 'Group' : 'Thread'} Theming
            </h3>
            <p className="text-xs text-[#A1A1AA]">
              Personalize colors, shapes, text contrast, and per-contact bubbles
            </p>
          </div>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Message Bubble Color */}
        <div className="mt-4">
          <label className="block text-[11px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-2">
            Your Message Bubble Color
          </label>
          <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
            {paletteOptions.map(color => (
              <button
                key={color}
                onClick={() => {
                  setSelectedUserColor(color);
                  HapticHelper.reactionClick();
                }}
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform shrink-0 ${
                  selectedUserColor === color ? 'ring-2 ring-white scale-110' : 'hover:scale-105'
                }`}
                style={{ backgroundColor: color }}
              >
                {selectedUserColor === color && <Check className="w-4 h-4 text-white drop-shadow" />}
              </button>
            ))}
          </div>
        </div>

        {/* User Bubble Shape */}
        <div className="mt-4">
          <label className="block text-[11px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-2">
            Your Bubble Style
          </label>
          <div className="grid grid-cols-4 gap-2">
            {shapes.map(s => {
              const isSelected = selectedUserShape === s.type;
              return (
                <button
                  key={s.type}
                  onClick={() => {
                    setSelectedUserShape(s.type);
                    HapticHelper.reactionClick();
                  }}
                  className={`py-2 px-2 text-xs font-semibold rounded-xl border transition-all ${
                    isSelected
                      ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4]'
                      : 'bg-[#141418] border-[#27272A] text-[#A1A1AA] hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Direct chat peer bubble styling */}
        {!conversation.isGroup && (
          <>
            <div className="mt-5">
              <label className="block text-[11px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-2">
                {conversation.recipientName.toUpperCase()}&apos;S BUBBLE COLOR
              </label>
              <div className="flex items-center gap-2.5 overflow-x-auto pb-1">
                {paletteOptions.map(color => (
                  <button
                    key={color}
                    onClick={() => {
                      setSelectedPeerColor(color);
                      HapticHelper.reactionClick();
                    }}
                    className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform shrink-0 ${
                      selectedPeerColor === color ? 'ring-2 ring-white scale-110' : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: color }}
                  >
                    {selectedPeerColor === color && <Check className="w-4 h-4 text-white drop-shadow" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-4">
              <label className="block text-[11px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-2">
                {conversation.recipientName.toUpperCase()}&apos;S BUBBLE STYLE
              </label>
              <div className="grid grid-cols-4 gap-2">
                {shapes.map(s => {
                  const isSelected = selectedPeerShape === s.type;
                  return (
                    <button
                      key={s.type}
                      onClick={() => {
                        setSelectedPeerShape(s.type);
                        HapticHelper.reactionClick();
                      }}
                      className={`py-2 px-2 text-xs font-semibold rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-[#06B6D4]/20 border-[#06B6D4] text-[#06B6D4]'
                          : 'bg-[#141418] border-[#27272A] text-[#A1A1AA] hover:text-white'
                      }`}
                    >
                      {s.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {/* Group chat: customize for each participant! */}
        {conversation.isGroup && members.length > 0 && (
          <div className="mt-5">
            <label className="block text-[11px] font-mono font-bold text-[#06B6D4] uppercase tracking-wider mb-2">
              Group Participants Bubble Styling
            </label>
            <div className="space-y-2">
              {members.map(member => {
                const current = memberConfigs[member] || { color: '#06B6D4', shape: 'ROUNDED' };
                return (
                  <div
                    key={member}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-[#141418] border border-[#27272A]"
                  >
                    <span className="text-xs font-semibold text-white">{member}</span>
                    <div className="flex items-center gap-2">
                      {/* Color Cycle Button */}
                      <button
                        title="Click to cycle color"
                        onClick={() => {
                          const idx = paletteOptions.indexOf(current.color);
                          const nextColor = paletteOptions[(idx + 1) % paletteOptions.length];
                          setMemberConfigs(prev => ({
                            ...prev,
                            [member]: { ...current, color: nextColor },
                          }));
                          HapticHelper.reactionClick();
                        }}
                        className="w-7 h-7 rounded-full border border-white/20 transition-transform active:scale-90"
                        style={{ backgroundColor: current.color }}
                      />
                      {/* Shape Cycle Button */}
                      <button
                        title="Click to cycle shape"
                        onClick={() => {
                          const shapeList: BubbleShapeType[] = ['ROUNDED', 'RECTANGULAR', 'PILL', 'CHAT_TAIL'];
                          const idx = shapeList.indexOf(current.shape);
                          const nextShape = shapeList[(idx + 1) % shapeList.length];
                          setMemberConfigs(prev => ({
                            ...prev,
                            [member]: { ...current, shape: nextShape },
                          }));
                          HapticHelper.reactionClick();
                        }}
                        className="px-2.5 py-1 rounded-lg bg-[#222228] text-[10px] font-mono font-bold text-[#A1A1AA] hover:text-white"
                      >
                        {current.shape}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Apply Button */}
        <div className="mt-6 pt-3 border-t border-[#1E1E24]">
          <button
            data-testid="save_theming_btn"
            onClick={handleApply}
            className="w-full py-3 rounded-2xl bg-[#06B6D4] hover:bg-[#22d3ee] text-black font-bold text-sm shadow-lg active:scale-[0.99] transition-all"
          >
            Apply to Chat
          </button>
        </div>
      </div>
    </div>
  );
};
