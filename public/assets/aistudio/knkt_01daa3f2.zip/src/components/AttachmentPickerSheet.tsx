import React from 'react';
import {
  Image,
  Camera,
  Mic,
  MapPin,
  Contact,
  FileText,
  X,
} from 'lucide-react';
import { HapticHelper } from '../utils/haptics';

interface AttachmentPickerSheetProps {
  onDismiss: () => void;
  onAttachPhoto: (uri: string, title: string) => void;
  onAttachAudio: (title: string) => void;
  onAttachLocation: (title: string) => void;
  onAttachContact: (name: string) => void;
}

export const AttachmentPickerSheet: React.FC<AttachmentPickerSheetProps> = ({
  onDismiss,
  onAttachPhoto,
  onAttachAudio,
  onAttachLocation,
  onAttachContact,
}) => {
  return (
    <div
      data-testid="attachment_picker_sheet"
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onDismiss}
    >
      <div
        className="w-full max-w-lg rounded-t-[32px] bg-[#0A0A0E] border-t border-x border-[#27272A] p-6 shadow-2xl animate-in slide-in-from-bottom duration-200"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3">
          <div>
            <h3 className="font-bold text-white text-lg">Share Content & Media</h3>
            <p className="text-xs text-[#A1A1AA]">
              Select media to attach over RCS or MMS protocol
            </p>
          </div>
          <button onClick={onDismiss} className="text-[#71717A] hover:text-white p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-4 gap-3 my-4">
          <button
            data-testid="attach_gallery_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachPhoto(
                'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=600',
                'sunset_gallery.jpg'
              );
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#3B82F6]/15 text-[#3B82F6] flex items-center justify-center">
              <Image className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Gallery</span>
          </button>

          <button
            data-testid="attach_camera_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachPhoto(
                'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600',
                'camera_capture.jpg'
              );
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center">
              <Camera className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Camera</span>
          </button>

          <button
            data-testid="attach_voice_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachAudio('Voice Memo (0:18)');
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#EF4444]/15 text-[#EF4444] flex items-center justify-center">
              <Mic className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Voice</span>
          </button>

          <button
            data-testid="attach_location_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachLocation('Namsan Seoul Tower • 37.5512° N, 126.9882° E');
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#F59E0B]/15 text-[#F59E0B] flex items-center justify-center">
              <MapPin className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Location</span>
          </button>
        </div>

        <div className="grid grid-cols-4 gap-3">
          <button
            data-testid="attach_contact_card_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachContact('Min-Jun Kim (+82 10-1234-5678)');
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#8B5CF6]/15 text-[#8B5CF6] flex items-center justify-center">
              <Contact className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Contact</span>
          </button>

          <button
            data-testid="attach_doc_btn"
            onClick={() => {
              HapticHelper.reactionClick();
              onAttachPhoto('', 'oneui_spec_doc.pdf');
              onDismiss();
            }}
            className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#141418] transition-colors"
          >
            <div className="w-14 h-14 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <span className="text-xs text-white/90 font-medium">Document</span>
          </button>
        </div>
      </div>
    </div>
  );
};
